package com.example.ai

import com.example.capability.CanvasViewport
import com.example.capability.CapabilityEngine
import com.example.data.local.prefs.UserPreferencesRepository
import com.example.data.local.security.SecureCredentialStore
import com.example.data.repository.WorkspaceRepository
import com.example.domain.model.ChatMessage
import com.example.domain.model.ChatRole
import kotlinx.coroutines.flow.first

data class OrchestratorTurnResult(
    val success: Boolean,
    val errorKind: AiErrorKind? = null
)

class AiWorkspaceOrchestrator(
    private val repository: WorkspaceRepository,
    private val prefsRepo: UserPreferencesRepository,
    private val credentialStore: SecureCredentialStore,
    private val providerRegistry: AiProviderRegistry,
    private val capabilityEngine: CapabilityEngine
) {

    suspend fun handleUserPrompt(
        userText: String,
        viewport: CanvasViewport
    ): OrchestratorTurnResult {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) return OrchestratorTurnResult(true)

        val userMessage = ChatMessage(role = ChatRole.USER, text = trimmed)
        repository.appendChatMessage(userMessage)

        val prefs = prefsRepo.getSnapshot()
        val provider = providerRegistry.getProvider(prefs.aiProviderId)
        val apiKey = credentialStore.getApiKey(provider.id)

        if (apiKey.isNullOrBlank()) {
            repository.appendChatMessage(
                ChatMessage(
                    role = ChatRole.ERROR,
                    text = "No API key configured for ${provider.displayName}. Open Settings to connect your API key."
                )
            )
            return OrchestratorTurnResult(false, AiErrorKind.MISSING_API_KEY)
        }

        val recentMessages = repository.chatMessagesFlow.first()
        val extraTurns = mutableListOf<Pair<String, List<AiToolResultFeedback>>>()
        val executedSummaries = mutableListOf<String>()
        var round = 0
        val maxRounds = 3

        while (round < maxRounds) {
            round++
            val pages = repository.getPagesOnce()
            val activePageId = repository.getActivePageId()
            val widgets = repository.getAllWidgetsOnce()
            val reminders = repository.getRemindersOnce()
            val appData = repository.getAllAppDataOnce()

            val systemInstruction = WorkspaceContextBuilder.buildSystemInstruction(
                pages = pages,
                activePageId = activePageId,
                widgets = widgets,
                reminders = reminders,
                appData = appData,
                viewport = viewport
            )

            when (
                val outcome = provider.runWorkspaceTurn(
                    apiKey = apiKey,
                    model = prefs.aiModel,
                    systemInstruction = systemInstruction,
                    recentMessages = recentMessages,
                    extraModelToolTurns = extraTurns
                )
            ) {
                is AiTurnOutcome.Error -> {
                    repository.appendChatMessage(
                        ChatMessage(
                            role = ChatRole.ERROR,
                            text = outcome.userMessage,
                            toolSummaries = executedSummaries.toList()
                        )
                    )
                    return OrchestratorTurnResult(false, outcome.kind)
                }

                is AiTurnOutcome.FinalResponse -> {
                    repository.appendChatMessage(
                        ChatMessage(
                            role = ChatRole.AI,
                            text = outcome.text,
                            toolSummaries = executedSummaries.toList()
                        )
                    )
                    return OrchestratorTurnResult(true)
                }

                is AiTurnOutcome.ToolCallsRequested -> {
                    val batchResult = capabilityEngine.executeToolBatch(
                        requests = outcome.toolCalls,
                        viewport = viewport,
                        logicalSummaryHint = null
                    )

                    val feedbacks = outcome.toolCalls.zip(batchResult.results).map { (req, res) ->
                        if (res.success) {
                            executedSummaries.add(res.message)
                        } else {
                            executedSummaries.add("Rejected: ${res.message}")
                        }
                        AiToolResultFeedback(
                            callId = req.id,
                            toolName = req.name,
                            success = res.success,
                            message = res.message,
                            payloadJson = res.payloadJson
                        )
                    }
                    extraTurns.add(outcome.rawAssistantContentJson to feedbacks)
                }
            }
        }

        val fallbackText = if (executedSummaries.isNotEmpty()) {
            "Completed: ${executedSummaries.joinToString("; ")}."
        } else {
            "Done."
        }
        repository.appendChatMessage(
            ChatMessage(
                role = ChatRole.AI,
                text = fallbackText,
                toolSummaries = executedSummaries.toList()
            )
        )
        return OrchestratorTurnResult(true)
    }
}
