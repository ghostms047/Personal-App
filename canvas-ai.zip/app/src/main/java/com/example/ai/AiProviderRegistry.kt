package com.example.ai

class AiProviderRegistry {
    private val providers: Map<String, AiProvider> = listOf(
        GeminiAiProvider()
    ).associateBy { it.id }

    fun getAllProviders(): List<AiProvider> = providers.values.toList()

    fun getProvider(id: String): AiProvider {
        return providers[id] ?: providers.values.first()
    }
}
