package com.example.ai

import com.example.capability.CanvasViewport
import com.example.domain.model.CanvasWidget
import com.example.domain.model.KeyValueEntry
import com.example.domain.model.ReminderConfig
import com.example.domain.model.WidgetData
import com.example.domain.model.WorkspacePage
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WorkspaceContextBuilder {

    fun buildSystemInstruction(
        pages: List<WorkspacePage>,
        activePageId: String,
        widgets: List<CanvasWidget>,
        reminders: List<ReminderConfig>,
        appData: List<KeyValueEntry>,
        viewport: CanvasViewport
    ): String {
        val stateJson = buildContextJson(
            pages = pages,
            activePageId = activePageId,
            widgets = widgets,
            reminders = reminders,
            appData = appData,
            viewport = viewport
        )
        val nowFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

        return """
You are Personal AI inside "Personal App", an infinite digital canvas workspace on Android.
Your job is to build, arrange, style, and manage workspace widgets, pages, reminders, and local data exclusively through the provided Capability API tools.

STRICT RULES:
1. NEVER output source code, Kotlin, XML, or claim you modified source files. Always use the provided tools.
2. Only reference widgetIds, pageIds, and notificationIds that appear in the WORKSPACE_STATE JSON below (or were just returned by a tool call in this turn).
3. If the user refers to a widget by type/name (e.g. "move the clock" or "delete the notes widget") and there are MULTIPLE matching widgets on the active page, DO NOT guess—ask a brief clarifying question naming the candidates and their IDs/titles.
4. If the user asks for a multi-widget workspace (e.g., "Build me a study dashboard"), call multiple `createWidget` tools in the same response, laying them out cleanly in a grid without overlapping (use `viewport.visibleTopLeft` as origin, ~270dp column spacing, ~220dp row spacing).
5. When moving to semantic positions like "top right" or "center", use `moveWidget` with `anchor` ("top_right", "top_left", "center", "bottom_left", "bottom_right", "left", "right").
6. When making a widget "bigger" or "smaller", use `resizeWidget` with `scaleFactor` (e.g. 1.35 for larger, 0.75 for smaller).
7. For Pomodoro timers, default to 1500 seconds (25 minutes) unless the user specifies another duration.
8. Keep your final reply concise, calm, and helpful (1–2 sentences confirming what you did).

CURRENT_LOCAL_TIME: $nowFormatted
WORKSPACE_STATE:
$stateJson
        """.trimIndent()
    }

    private fun buildContextJson(
        pages: List<WorkspacePage>,
        activePageId: String,
        widgets: List<CanvasWidget>,
        reminders: List<ReminderConfig>,
        appData: List<KeyValueEntry>,
        viewport: CanvasViewport
    ): String {
        val root = JSONObject()
        root.put("activePageId", activePageId)

        val visibleLeft = (-viewport.panX / viewport.zoom).toInt()
        val visibleTop = (-viewport.panY / viewport.zoom).toInt()
        root.put(
            "viewport",
            JSONObject().apply {
                put("visibleLeft", visibleLeft)
                put("visibleTop", visibleTop)
                put("visibleWidthDp", (viewport.viewportWidthDp / viewport.zoom).toInt())
                put("visibleHeightDp", (viewport.viewportHeightDp / viewport.zoom).toInt())
                put("zoom", viewport.zoom.toDouble())
            }
        )

        val pagesArr = JSONArray()
        pages.forEach { p ->
            pagesArr.put(JSONObject().apply {
                put("id", p.id)
                put("title", p.title)
                put("isActive", p.id == activePageId)
            })
        }
        root.put("pages", pagesArr)

        val widgetsArr = JSONArray()
        widgets.filter { it.pageId == activePageId }.forEach { w ->
            widgetsArr.put(JSONObject().apply {
                put("id", w.id)
                put("type", w.type.wireName)
                put("title", w.title)
                put("x", w.x.toInt())
                put("y", w.y.toInt())
                put("width", w.width.toInt())
                put("height", w.height.toInt())
                put("accentColor", w.style.accentColorKey)
                put("summary", summarizeWidgetData(w.data))
            })
        }
        root.put("activePageWidgets", widgetsArr)

        val otherWidgetCount = widgets.count { it.pageId != activePageId }
        root.put("otherPagesWidgetCount", otherWidgetCount)

        val remindersArr = JSONArray()
        reminders.forEach { r ->
            remindersArr.put(JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("time", "%02d:%02d".format(r.hour, r.minute))
                put("daily", r.isDailyRecurring)
                put("enabled", r.enabled)
            })
        }
        root.put("reminders", remindersArr)

        val dataKeysArr = JSONArray()
        appData.forEach { dataKeysArr.put(it.key) }
        root.put("storedDataKeys", dataKeysArr)

        return root.toString()
    }

    private fun summarizeWidgetData(data: WidgetData): String = when (data) {
        is WidgetData.TextData -> data.content.take(80)
        is WidgetData.TodoData -> "${data.items.count { it.completed }}/${data.items.size} tasks completed"
        is WidgetData.NotesData -> data.content.take(80).ifBlank { "empty note" }
        is WidgetData.ClockData -> if (data.is24Hour) "24h clock" else "12h clock"
        is WidgetData.TimerData -> "${data.remainingSeconds}s / ${data.durationSeconds}s (${if (data.isRunning) "running" else "paused"})"
        is WidgetData.CounterData -> "${data.value} ${data.unit}".trim()
        is WidgetData.ButtonData -> "label='${data.label}', taps=${data.tapCount}"
        is WidgetData.ProgressData -> "${data.current}/${data.target} ${data.unit}".trim()
        is WidgetData.InputData -> "${data.submittedValues.size} logged entries"
    }
}
