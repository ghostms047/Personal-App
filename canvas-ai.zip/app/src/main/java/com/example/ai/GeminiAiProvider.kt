package com.example.ai

import com.example.capability.CapabilityToolRegistry
import com.example.capability.ToolCallRequest
import com.example.domain.model.ChatMessage
import com.example.domain.model.ChatRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.UUID
import java.util.concurrent.TimeUnit

class GeminiAiProvider : AiProvider {

    override val id: String = "gemini"
    override val displayName: String = "Google Gemini"
    override val description: String = "Official Gemini API with structured tool calling."

    override val supportedModels: List<AiModelInfo> = listOf(
        AiModelInfo("gemini-2.5-flash", "Gemini 2.5 Flash", "Fast, balanced tool calling & workspace actions"),
        AiModelInfo("gemini-2.5-pro", "Gemini 2.5 Pro", "Deep reasoning for complex workspace layouts"),
        AiModelInfo("gemini-2.0-flash", "Gemini 2.0 Flash", "Reliable low-latency assistant model")
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    override suspend fun testConnection(apiKey: String, model: String): AiConnectionResult =
        withContext(Dispatchers.IO) {
            val trimmedKey = apiKey.trim()
            if (trimmedKey.isEmpty()) {
                return@withContext AiConnectionResult.Failure(
                    AiErrorKind.MISSING_API_KEY,
                    "Please enter an API key first."
                )
            }
            val targetModel = model.trim().ifBlank { "gemini-2.5-flash" }
            val start = System.currentTimeMillis()
            val bodyJson = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().put(JSONObject().put("text", "Reply with OK.")))
                        }
                    )
                )
                put("generationConfig", JSONObject().put("maxOutputTokens", 8))
            }.toString()

            val request = Request.Builder()
                .url("$BASE_URL/$targetModel:generateContent")
                .addHeader("x-goog-api-key", trimmedKey)
                .post(bodyJson.toRequestBody(jsonMediaType))
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    val rawBody = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val latency = System.currentTimeMillis() - start
                        AiConnectionResult.Success(latencyMs = latency, modelId = targetModel)
                    } else {
                        val (kind, msg) = mapHttpError(response.code, rawBody)
                        AiConnectionResult.Failure(kind, msg)
                    }
                }
            } catch (e: UnknownHostException) {
                AiConnectionResult.Failure(
                    AiErrorKind.NETWORK_UNAVAILABLE,
                    "No internet connection. Check your network and try again."
                )
            } catch (e: SocketTimeoutException) {
                AiConnectionResult.Failure(
                    AiErrorKind.TIMEOUT,
                    "Connection to Gemini timed out. Please try again."
                )
            } catch (e: IOException) {
                AiConnectionResult.Failure(
                    AiErrorKind.NETWORK_UNAVAILABLE,
                    "Network error: ${e.localizedMessage ?: "Unable to reach Gemini API."}"
                )
            }
        }

    override suspend fun runWorkspaceTurn(
        apiKey: String,
        model: String,
        systemInstruction: String,
        recentMessages: List<ChatMessage>,
        extraModelToolTurns: List<Pair<String, List<AiToolResultFeedback>>>
    ): AiTurnOutcome = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isEmpty()) {
            return@withContext AiTurnOutcome.Error(
                AiErrorKind.MISSING_API_KEY,
                "No API key configured. Add your Gemini API key in Settings."
            )
        }
        val targetModel = model.trim().ifBlank { "gemini-2.5-flash" }

        val contents = JSONArray()
        recentMessages
            .filter { it.role == ChatRole.USER || it.role == ChatRole.AI }
            .takeLast(12)
            .forEach { msg ->
                val role = if (msg.role == ChatRole.USER) "user" else "model"
                contents.put(
                    JSONObject().apply {
                        put("role", role)
                        put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                    }
                )
            }

        extraModelToolTurns.forEach { (rawModelContentStr, feedbacks) ->
            runCatching { JSONObject(rawModelContentStr) }.getOrNull()?.let { modelContent ->
                contents.put(modelContent)
            }
            val fnResponseParts = JSONArray()
            feedbacks.forEach { fb ->
                val respObj = JSONObject().apply {
                    put("success", fb.success)
                    put("message", fb.message)
                    val payloadObj = runCatching { JSONObject(fb.payloadJson) }.getOrNull()
                    if (payloadObj != null && payloadObj.length() > 0) {
                        put("data", payloadObj)
                    }
                }
                fnResponseParts.put(
                    JSONObject().apply {
                        put(
                            "functionResponse",
                            JSONObject().apply {
                                put("name", fb.toolName)
                                put("response", respObj)
                            }
                        )
                    }
                )
            }
            contents.put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", fnResponseParts)
                }
            )
        }

        val payload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                }
            )
            put("contents", contents)
            put(
                "tools",
                JSONArray().put(
                    JSONObject().put(
                        "functionDeclarations",
                        CapabilityToolRegistry.buildGeminiFunctionDeclarations()
                    )
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", 0.2)
                }
            )
        }

        val request = Request.Builder()
            .url("$BASE_URL/$targetModel:generateContent")
            .addHeader("x-goog-api-key", trimmedKey)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val (kind, msg) = mapHttpError(response.code, rawBody)
                    return@withContext AiTurnOutcome.Error(kind, msg)
                }
                parseGeminiResponse(rawBody)
            }
        } catch (e: UnknownHostException) {
            AiTurnOutcome.Error(
                AiErrorKind.NETWORK_UNAVAILABLE,
                "You appear to be offline. Existing widgets still work offline."
            )
        } catch (e: SocketTimeoutException) {
            AiTurnOutcome.Error(
                AiErrorKind.TIMEOUT,
                "AI request timed out. Please try again."
            )
        } catch (e: IOException) {
            AiTurnOutcome.Error(
                AiErrorKind.NETWORK_UNAVAILABLE,
                "Network error: ${e.localizedMessage ?: "Connection interrupted."}"
            )
        } catch (e: Exception) {
            AiTurnOutcome.Error(
                AiErrorKind.MALFORMED_RESPONSE,
                "Unexpected AI response error: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    private fun parseGeminiResponse(rawBody: String): AiTurnOutcome {
        val root = runCatching { JSONObject(rawBody) }.getOrNull()
            ?: return AiTurnOutcome.Error(
                AiErrorKind.MALFORMED_RESPONSE,
                "Received invalid JSON from Gemini."
            )

        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val blockReason = root.optJSONObject("promptFeedback")?.optString("blockReason", "")
            val msg = if (!blockReason.isNullOrBlank()) {
                "Request could not be fulfilled ($blockReason)."
            } else {
                "AI returned an empty response."
            }
            return AiTurnOutcome.Error(AiErrorKind.MALFORMED_RESPONSE, msg)
        }

        val firstCandidate = candidates.optJSONObject(0)
            ?: return AiTurnOutcome.Error(AiErrorKind.MALFORMED_RESPONSE, "Malformed candidate in AI response.")

        val content = firstCandidate.optJSONObject("content")
            ?: return AiTurnOutcome.Error(AiErrorKind.MALFORMED_RESPONSE, "Missing content in AI response.")

        val parts = content.optJSONArray("parts") ?: JSONArray()
        val textParts = mutableListOf<String>()
        val toolCalls = mutableListOf<ToolCallRequest>()

        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            if (part.has("text")) {
                val t = part.optString("text", "").trim()
                if (t.isNotEmpty()) textParts.add(t)
            }
            if (part.has("functionCall")) {
                val fnCall = part.optJSONObject("functionCall") ?: continue
                val fnName = fnCall.optString("name", "").trim()
                val argsObj = fnCall.optJSONObject("args") ?: JSONObject()
                if (fnName.isNotEmpty()) {
                    toolCalls.add(
                        ToolCallRequest(
                            id = UUID.randomUUID().toString(),
                            name = fnName,
                            argsJson = argsObj.toString()
                        )
                    )
                }
            }
        }

        return if (toolCalls.isNotEmpty()) {
            AiTurnOutcome.ToolCallsRequested(
                toolCalls = toolCalls,
                assistantText = textParts.joinToString("\n").ifBlank { null },
                rawAssistantContentJson = content.toString()
            )
        } else {
            val combinedText = textParts.joinToString("\n").ifBlank { "Done." }
            AiTurnOutcome.FinalResponse(combinedText)
        }
    }

    private fun mapHttpError(code: Int, rawBody: String): Pair<AiErrorKind, String> {
        val apiMessage = runCatching {
            JSONObject(rawBody).optJSONObject("error")?.optString("message", "")
        }.getOrNull().orEmpty()

        return when (code) {
            400 -> {
                if (apiMessage.contains("API key", ignoreCase = true) ||
                    apiMessage.contains("API_KEY_INVALID", ignoreCase = true)
                ) {
                    AiErrorKind.INVALID_API_KEY to "Invalid API key. Check your key in Settings."
                } else {
                    AiErrorKind.API_ERROR to (apiMessage.ifBlank { "Bad request sent to Gemini (400)." })
                }
            }
            401, 403 -> AiErrorKind.INVALID_API_KEY to "Invalid or unauthorized API key ($code)."
            404 -> AiErrorKind.MODEL_NOT_FOUND to "Selected model was not found ($code). Choose another model in Settings."
            429 -> AiErrorKind.RATE_LIMITED to "Rate limit reached (429). Please wait a moment and try again."
            in 500..599 -> AiErrorKind.API_ERROR to "Gemini service temporarily unavailable ($code)."
            else -> AiErrorKind.API_ERROR to (apiMessage.ifBlank { "AI request failed with HTTP $code." })
        }
    }

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
    }
}
