package com.example.ai

import com.example.capability.ToolCallRequest
import com.example.domain.model.ChatMessage

data class AiModelInfo(
    val id: String,
    val displayName: String,
    val description: String
)

enum class AiErrorKind {
    MISSING_API_KEY,
    INVALID_API_KEY,
    NETWORK_UNAVAILABLE,
    TIMEOUT,
    RATE_LIMITED,
    MODEL_NOT_FOUND,
    MALFORMED_RESPONSE,
    API_ERROR
}

sealed class AiConnectionResult {
    data class Success(val latencyMs: Long, val modelId: String) : AiConnectionResult()
    data class Failure(val kind: AiErrorKind, val message: String) : AiConnectionResult()
}

data class AiToolResultFeedback(
    val callId: String,
    val toolName: String,
    val success: Boolean,
    val message: String,
    val payloadJson: String
)

sealed class AiTurnOutcome {
    data class ToolCallsRequested(
        val toolCalls: List<ToolCallRequest>,
        val assistantText: String?,
        val rawAssistantContentJson: String
    ) : AiTurnOutcome()

    data class FinalResponse(
        val text: String
    ) : AiTurnOutcome()

    data class Error(
        val kind: AiErrorKind,
        val userMessage: String
    ) : AiTurnOutcome()
}

interface AiProvider {
    val id: String
    val displayName: String
    val description: String
    val supportedModels: List<AiModelInfo>

    suspend fun testConnection(apiKey: String, model: String): AiConnectionResult

    suspend fun runWorkspaceTurn(
        apiKey: String,
        model: String,
        systemInstruction: String,
        recentMessages: List<ChatMessage>,
        extraModelToolTurns: List<Pair<String, List<AiToolResultFeedback>>>
    ): AiTurnOutcome
}
