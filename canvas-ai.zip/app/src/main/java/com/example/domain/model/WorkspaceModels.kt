package com.example.domain.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class WidgetType(val wireName: String, val displayName: String) {
    TEXT("text", "Text"),
    TODO("todo", "Todo List"),
    NOTES("notes", "Notes"),
    CLOCK("clock", "Clock"),
    TIMER("timer", "Timer"),
    COUNTER("counter", "Counter"),
    BUTTON("button", "Button"),
    PROGRESS("progress", "Progress"),
    INPUT("input", "Input");

    companion object {
        fun fromWireName(raw: String?): WidgetType? {
            if (raw.isNullOrBlank()) return null
            val normalized = raw.trim().lowercase()
            return entries.firstOrNull { it.wireName == normalized || it.name.lowercase() == normalized }
        }
    }
}

enum class CardTone(val wireName: String) {
    DEFAULT("default"),
    TINTED("tinted"),
    OUTLINED("outlined");

    companion object {
        fun fromWireName(raw: String?): CardTone {
            val normalized = raw?.trim()?.lowercase()
            return entries.firstOrNull { it.wireName == normalized } ?: DEFAULT
        }
    }
}

data class WidgetStyle(
    val accentColorKey: String = "slate",
    val cardTone: CardTone = CardTone.DEFAULT,
    val fontSizeScale: Float = 1.0f,
    val cornerRadiusDp: Int = 18
) {
    fun toJson(): String = JSONObject().apply {
        put("accentColorKey", accentColorKey)
        put("cardTone", cardTone.wireName)
        put("fontSizeScale", fontSizeScale.toDouble())
        put("cornerRadiusDp", cornerRadiusDp)
    }.toString()

    companion object {
        val ALLOWED_ACCENTS = setOf("slate", "cobalt", "sage", "amber", "plum", "terracotta")

        fun fromJson(json: String): WidgetStyle {
            return runCatching {
                val obj = JSONObject(json)
                WidgetStyle(
                    accentColorKey = obj.optString("accentColorKey", "slate")
                        .takeIf { it in ALLOWED_ACCENTS } ?: "slate",
                    cardTone = CardTone.fromWireName(obj.optString("cardTone", "default")),
                    fontSizeScale = obj.optDouble("fontSizeScale", 1.0).toFloat().coerceIn(0.75f, 1.8f),
                    cornerRadiusDp = obj.optInt("cornerRadiusDp", 18).coerceIn(8, 28)
                )
            }.getOrDefault(WidgetStyle())
        }
    }
}

data class TodoItem(
    val id: String = UUID.randomUUID().toString().take(8),
    val text: String,
    val completed: Boolean = false
)

sealed class WidgetData {
    data class TextData(
        val content: String = "",
        val subtitle: String = ""
    ) : WidgetData()

    data class TodoData(
        val items: List<TodoItem> = emptyList()
    ) : WidgetData()

    data class NotesData(
        val content: String = ""
    ) : WidgetData()

    data class ClockData(
        val is24Hour: Boolean = false,
        val showSeconds: Boolean = true,
        val label: String = ""
    ) : WidgetData()

    data class TimerData(
        val durationSeconds: Int = 1500,
        val remainingSeconds: Int = 1500,
        val isRunning: Boolean = false,
        val lastTickEpochMs: Long = 0L
    ) : WidgetData()

    data class CounterData(
        val value: Int = 0,
        val step: Int = 1,
        val unit: String = ""
    ) : WidgetData()

    data class ButtonData(
        val label: String = "Run Action",
        val actionType: String = "increment_counter",
        val linkedWidgetId: String? = null,
        val actionDescription: String = "",
        val tapCount: Int = 0
    ) : WidgetData()

    data class ProgressData(
        val current: Float = 0f,
        val target: Float = 100f,
        val unit: String = "%"
    ) : WidgetData()

    data class InputData(
        val placeholder: String = "Enter value…",
        val currentValue: String = "",
        val submittedValues: List<String> = emptyList()
    ) : WidgetData()

    fun toJson(): String {
        val obj = JSONObject()
        when (this) {
            is TextData -> {
                obj.put("kind", "text")
                obj.put("content", content)
                obj.put("subtitle", subtitle)
            }
            is TodoData -> {
                obj.put("kind", "todo")
                val arr = JSONArray()
                items.forEach { item ->
                    arr.put(JSONObject().apply {
                        put("id", item.id)
                        put("text", item.text)
                        put("completed", item.completed)
                    })
                }
                obj.put("items", arr)
            }
            is NotesData -> {
                obj.put("kind", "notes")
                obj.put("content", content)
            }
            is ClockData -> {
                obj.put("kind", "clock")
                obj.put("is24Hour", is24Hour)
                obj.put("showSeconds", showSeconds)
                obj.put("label", label)
            }
            is TimerData -> {
                obj.put("kind", "timer")
                obj.put("durationSeconds", durationSeconds)
                obj.put("remainingSeconds", remainingSeconds)
                obj.put("isRunning", isRunning)
                obj.put("lastTickEpochMs", lastTickEpochMs)
            }
            is CounterData -> {
                obj.put("kind", "counter")
                obj.put("value", value)
                obj.put("step", step)
                obj.put("unit", unit)
            }
            is ButtonData -> {
                obj.put("kind", "button")
                obj.put("label", label)
                obj.put("actionType", actionType)
                if (linkedWidgetId != null) obj.put("linkedWidgetId", linkedWidgetId)
                obj.put("actionDescription", actionDescription)
                obj.put("tapCount", tapCount)
            }
            is ProgressData -> {
                obj.put("kind", "progress")
                obj.put("current", current.toDouble())
                obj.put("target", target.toDouble())
                obj.put("unit", unit)
            }
            is InputData -> {
                obj.put("kind", "input")
                obj.put("placeholder", placeholder)
                obj.put("currentValue", currentValue)
                val arr = JSONArray()
                submittedValues.forEach { arr.put(it) }
                obj.put("submittedValues", arr)
            }
        }
        return obj.toString()
    }

    companion object {
        fun fromJson(type: WidgetType, json: String): WidgetData {
            return runCatching {
                val obj = JSONObject(json)
                when (type) {
                    WidgetType.TEXT -> TextData(
                        content = obj.optString("content", ""),
                        subtitle = obj.optString("subtitle", "")
                    )
                    WidgetType.TODO -> {
                        val arr = obj.optJSONArray("items") ?: JSONArray()
                        val list = buildList {
                            for (i in 0 until arr.length()) {
                                val itemObj = arr.optJSONObject(i) ?: continue
                                val text = itemObj.optString("text", "").trim()
                                if (text.isNotEmpty()) {
                                    add(
                                        TodoItem(
                                            id = itemObj.optString("id", UUID.randomUUID().toString().take(8)),
                                            text = text,
                                            completed = itemObj.optBoolean("completed", false)
                                        )
                                    )
                                }
                            }
                        }
                        TodoData(items = list)
                    }
                    WidgetType.NOTES -> NotesData(
                        content = obj.optString("content", "")
                    )
                    WidgetType.CLOCK -> ClockData(
                        is24Hour = obj.optBoolean("is24Hour", false),
                        showSeconds = obj.optBoolean("showSeconds", true),
                        label = obj.optString("label", "")
                    )
                    WidgetType.TIMER -> {
                        val dur = obj.optInt("durationSeconds", 1500).coerceIn(1, 86400)
                        val rem = obj.optInt("remainingSeconds", dur).coerceIn(0, dur)
                        TimerData(
                            durationSeconds = dur,
                            remainingSeconds = rem,
                            isRunning = obj.optBoolean("isRunning", false),
                            lastTickEpochMs = obj.optLong("lastTickEpochMs", 0L)
                        )
                    }
                    WidgetType.COUNTER -> CounterData(
                        value = obj.optInt("value", 0),
                        step = obj.optInt("step", 1).coerceIn(1, 10000),
                        unit = obj.optString("unit", "")
                    )
                    WidgetType.BUTTON -> ButtonData(
                        label = obj.optString("label", "Action"),
                        actionType = obj.optString("actionType", "increment_counter"),
                        linkedWidgetId = obj.optString("linkedWidgetId", "").ifBlank { null },
                        actionDescription = obj.optString("actionDescription", ""),
                        tapCount = obj.optInt("tapCount", 0)
                    )
                    WidgetType.PROGRESS -> {
                        val target = obj.optDouble("target", 100.0).toFloat().coerceAtLeast(1f)
                        val current = obj.optDouble("current", 0.0).toFloat().coerceAtLeast(0f)
                        ProgressData(
                            current = current,
                            target = target,
                            unit = obj.optString("unit", "%")
                        )
                    }
                    WidgetType.INPUT -> {
                        val arr = obj.optJSONArray("submittedValues") ?: JSONArray()
                        val list = buildList {
                            for (i in 0 until arr.length()) {
                                val entry = arr.optString(i, "")
                                if (entry.isNotEmpty()) add(entry)
                            }
                        }
                        InputData(
                            placeholder = obj.optString("placeholder", "Enter value…"),
                            currentValue = obj.optString("currentValue", ""),
                            submittedValues = list
                        )
                    }
                }
            }.getOrElse { defaultForType(type) }
        }

        fun defaultForType(type: WidgetType): WidgetData = when (type) {
            WidgetType.TEXT -> TextData(content = "Workspace note")
            WidgetType.TODO -> TodoData(items = emptyList())
            WidgetType.NOTES -> NotesData(content = "")
            WidgetType.CLOCK -> ClockData()
            WidgetType.TIMER -> TimerData(durationSeconds = 1500, remainingSeconds = 1500)
            WidgetType.COUNTER -> CounterData(value = 0, step = 1)
            WidgetType.BUTTON -> ButtonData(label = "Tap", actionType = "tap_counter")
            WidgetType.PROGRESS -> ProgressData(current = 0f, target = 100f, unit = "%")
            WidgetType.INPUT -> InputData(placeholder = "Type and save…")
        }
    }
}

data class WorkspacePage(
    val id: String,
    val title: String,
    val sortOrder: Int,
    val createdAt: Long,
    val updatedAt: Long
)

data class CanvasWidget(
    val id: String,
    val pageId: String,
    val type: WidgetType,
    val title: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val zIndex: Int,
    val style: WidgetStyle,
    val data: WidgetData,
    val createdAt: Long,
    val updatedAt: Long
)

data class ReminderConfig(
    val id: String,
    val title: String,
    val message: String,
    val hour: Int,
    val minute: Int,
    val isDailyRecurring: Boolean,
    val triggerAtMillis: Long,
    val enabled: Boolean,
    val createdAt: Long
)

data class KeyValueEntry(
    val key: String,
    val value: String,
    val updatedAt: Long
)

data class ActionHistoryEntry(
    val id: String,
    val summary: String,
    val timestamp: Long,
    val beforeSnapshotJson: String,
    val afterSnapshotJson: String,
    val isUndone: Boolean = false
)

enum class ChatRole {
    USER, AI, SYSTEM, ERROR
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: ChatRole,
    val text: String,
    val toolSummaries: List<String> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)
