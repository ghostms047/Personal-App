package com.example.domain.model

import org.json.JSONArray
import org.json.JSONObject

data class WorkspaceSnapshot(
    val pages: List<WorkspacePage>,
    val widgets: List<CanvasWidget>,
    val reminders: List<ReminderConfig>,
    val keyValueEntries: List<KeyValueEntry>,
    val activePageId: String
) {
    fun toJson(): String {
        val root = JSONObject()
        root.put("activePageId", activePageId)

        val pagesArr = JSONArray()
        pages.forEach { p ->
            pagesArr.put(JSONObject().apply {
                put("id", p.id)
                put("title", p.title)
                put("sortOrder", p.sortOrder)
                put("createdAt", p.createdAt)
                put("updatedAt", p.updatedAt)
            })
        }
        root.put("pages", pagesArr)

        val widgetsArr = JSONArray()
        widgets.forEach { w ->
            widgetsArr.put(JSONObject().apply {
                put("id", w.id)
                put("pageId", w.pageId)
                put("type", w.type.wireName)
                put("title", w.title)
                put("x", w.x.toDouble())
                put("y", w.y.toDouble())
                put("width", w.width.toDouble())
                put("height", w.height.toDouble())
                put("zIndex", w.zIndex)
                put("styleJson", w.style.toJson())
                put("dataJson", w.data.toJson())
                put("createdAt", w.createdAt)
                put("updatedAt", w.updatedAt)
            })
        }
        root.put("widgets", widgetsArr)

        val remindersArr = JSONArray()
        reminders.forEach { r ->
            remindersArr.put(JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("message", r.message)
                put("hour", r.hour)
                put("minute", r.minute)
                put("isDailyRecurring", r.isDailyRecurring)
                put("triggerAtMillis", r.triggerAtMillis)
                put("enabled", r.enabled)
                put("createdAt", r.createdAt)
            })
        }
        root.put("reminders", remindersArr)

        val kvArr = JSONArray()
        keyValueEntries.forEach { kv ->
            kvArr.put(JSONObject().apply {
                put("key", kv.key)
                put("value", kv.value)
                put("updatedAt", kv.updatedAt)
            })
        }
        root.put("keyValueEntries", kvArr)
        return root.toString()
    }

    companion object {
        fun fromJson(json: String): WorkspaceSnapshot? = runCatching {
            val root = JSONObject(json)
            val activePageId = root.optString("activePageId", "page_main")

            val pagesArr = root.optJSONArray("pages") ?: JSONArray()
            val pages = buildList {
                for (i in 0 until pagesArr.length()) {
                    val o = pagesArr.optJSONObject(i) ?: continue
                    add(
                        WorkspacePage(
                            id = o.getString("id"),
                            title = o.getString("title"),
                            sortOrder = o.optInt("sortOrder", i),
                            createdAt = o.optLong("createdAt", 0L),
                            updatedAt = o.optLong("updatedAt", 0L)
                        )
                    )
                }
            }

            val widgetsArr = root.optJSONArray("widgets") ?: JSONArray()
            val widgets = buildList {
                for (i in 0 until widgetsArr.length()) {
                    val o = widgetsArr.optJSONObject(i) ?: continue
                    val type = WidgetType.fromWireName(o.optString("type")) ?: continue
                    add(
                        CanvasWidget(
                            id = o.getString("id"),
                            pageId = o.getString("pageId"),
                            type = type,
                            title = o.optString("title", type.displayName),
                            x = o.optDouble("x", 0.0).toFloat(),
                            y = o.optDouble("y", 0.0).toFloat(),
                            width = o.optDouble("width", 260.0).toFloat(),
                            height = o.optDouble("height", 180.0).toFloat(),
                            zIndex = o.optInt("zIndex", 0),
                            style = WidgetStyle.fromJson(o.optString("styleJson", "{}")),
                            data = WidgetData.fromJson(type, o.optString("dataJson", "{}")),
                            createdAt = o.optLong("createdAt", 0L),
                            updatedAt = o.optLong("updatedAt", 0L)
                        )
                    )
                }
            }

            val remindersArr = root.optJSONArray("reminders") ?: JSONArray()
            val reminders = buildList {
                for (i in 0 until remindersArr.length()) {
                    val o = remindersArr.optJSONObject(i) ?: continue
                    add(
                        ReminderConfig(
                            id = o.getString("id"),
                            title = o.getString("title"),
                            message = o.getString("message"),
                            hour = o.getInt("hour"),
                            minute = o.getInt("minute"),
                            isDailyRecurring = o.optBoolean("isDailyRecurring", false),
                            triggerAtMillis = o.optLong("triggerAtMillis", 0L),
                            enabled = o.optBoolean("enabled", true),
                            createdAt = o.optLong("createdAt", 0L)
                        )
                    )
                }
            }

            val kvArr = root.optJSONArray("keyValueEntries") ?: JSONArray()
            val kvEntries = buildList {
                for (i in 0 until kvArr.length()) {
                    val o = kvArr.optJSONObject(i) ?: continue
                    add(
                        KeyValueEntry(
                            key = o.getString("key"),
                            value = o.getString("value"),
                            updatedAt = o.optLong("updatedAt", 0L)
                        )
                    )
                }
            }

            WorkspaceSnapshot(
                pages = pages,
                widgets = widgets,
                reminders = reminders,
                keyValueEntries = kvEntries,
                activePageId = activePageId
            )
        }.getOrNull()
    }
}
