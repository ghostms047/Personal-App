package com.example.capability

import org.json.JSONArray
import org.json.JSONObject

object CapabilityToolRegistry {

    val ALLOWED_TOOL_NAMES = setOf(
        "createWidget",
        "updateWidget",
        "deleteWidget",
        "moveWidget",
        "resizeWidget",
        "createPage",
        "deletePage",
        "switchPage",
        "createButton",
        "createText",
        "createInput",
        "createTimer",
        "createNotification",
        "deleteNotifications",
        "saveData",
        "readData",
        "deleteData",
        "changeStyle",
        "undoAction",
        "redoAction",
        "addTodoItem",
        "toggleTodoItem",
        "deleteTodoItem"
    )

    fun buildGeminiFunctionDeclarations(): JSONArray {
        val declarations = JSONArray()

        declarations.put(
            fn(
                name = "createWidget",
                description = "Create a new modular widget on the infinite canvas. Types: text, todo, notes, clock, timer, counter, button, progress, input.",
                props = mapOf(
                    "type" to strProp("Widget type: text, todo, notes, clock, timer, counter, button, progress, input"),
                    "title" to strProp("Display title of the widget"),
                    "pageId" to strProp("Optional target page ID. Defaults to active page."),
                    "x" to numProp("Optional X coordinate on canvas in dp"),
                    "y" to numProp("Optional Y coordinate on canvas in dp"),
                    "width" to numProp("Optional width in dp (160 to 600)"),
                    "height" to numProp("Optional height in dp (100 to 600)"),
                    "accentColor" to strProp("Optional accent key: slate, cobalt, sage, amber, plum, terracotta"),
                    "cardTone" to strProp("Optional card tone: default, tinted, outlined"),
                    "content" to strProp("Optional text or notes content"),
                    "subtitle" to strProp("Optional subtitle for text widget"),
                    "items" to strArrayProp("Optional initial todo items for todo widget"),
                    "durationSeconds" to intProp("Optional duration in seconds for timer widget (e.g. 1500 for 25 min Pomodoro)"),
                    "autoStart" to boolProp("Optional whether timer starts immediately"),
                    "is24Hour" to boolProp("Optional 24-hour clock format"),
                    "showSeconds" to boolProp("Optional show seconds on clock"),
                    "initialValue" to numProp("Optional initial numeric value for counter or progress"),
                    "targetValue" to numProp("Optional target value for progress widget"),
                    "step" to intProp("Optional step increment for counter"),
                    "unit" to strProp("Optional unit label for counter or progress (e.g. %, pages, cups)"),
                    "buttonLabel" to strProp("Optional label for button widget"),
                    "actionType" to strProp("Optional button action: increment_counter, start_timer, reset_timer, tap_counter"),
                    "linkedWidgetId" to strProp("Optional linked widget ID for button action"),
                    "placeholder" to strProp("Optional placeholder for input widget")
                ),
                required = listOf("type", "title")
            )
        )

        declarations.put(
            fn(
                name = "updateWidget",
                description = "Update properties or content of an existing widget by widgetId.",
                props = mapOf(
                    "widgetId" to strProp("ID of the widget to update, e.g. widget_001"),
                    "title" to strProp("Optional new title"),
                    "content" to strProp("Optional new text/notes content"),
                    "appendContent" to boolProp("If true, appends content to existing note/text instead of replacing"),
                    "subtitle" to strProp("Optional new subtitle"),
                    "durationSeconds" to intProp("Optional new timer duration in seconds"),
                    "timerAction" to strProp("Optional timer control: start, pause, reset"),
                    "counterValue" to intProp("Optional new counter value"),
                    "progressCurrent" to numProp("Optional new progress current value"),
                    "progressTarget" to numProp("Optional new progress target value"),
                    "is24Hour" to boolProp("Optional 24-hour toggle for clock")
                ),
                required = listOf("widgetId")
            )
        )

        declarations.put(
            fn(
                name = "deleteWidget",
                description = "Delete an existing widget from the canvas by widgetId.",
                props = mapOf(
                    "widgetId" to strProp("ID of the widget to delete")
                ),
                required = listOf("widgetId")
            )
        )

        declarations.put(
            fn(
                name = "moveWidget",
                description = "Move an existing widget to coordinates (x, y) or a viewport anchor (top_left, top_right, center, bottom_left, bottom_right, left, right).",
                props = mapOf(
                    "widgetId" to strProp("ID of the widget to move"),
                    "x" to numProp("Optional target X coordinate in dp"),
                    "y" to numProp("Optional target Y coordinate in dp"),
                    "anchor" to strProp("Optional semantic placement anchor: top_left, top_right, center, bottom_left, bottom_right, left, right")
                ),
                required = listOf("widgetId")
            )
        )

        declarations.put(
            fn(
                name = "resizeWidget",
                description = "Resize an existing widget by explicit width/height in dp or relative scaleFactor (e.g. 1.35 for larger, 0.75 for smaller).",
                props = mapOf(
                    "widgetId" to strProp("ID of the widget to resize"),
                    "width" to numProp("Optional new width in dp (160 to 640)"),
                    "height" to numProp("Optional new height in dp (100 to 640)"),
                    "scaleFactor" to numProp("Optional multiplier like 1.35 (bigger) or 0.75 (smaller)")
                ),
                required = listOf("widgetId")
            )
        )

        declarations.put(
            fn(
                name = "changeStyle",
                description = "Change visual style of an existing widget.",
                props = mapOf(
                    "widgetId" to strProp("ID of the widget to style"),
                    "accentColor" to strProp("Accent color key: slate, cobalt, sage, amber, plum, terracotta"),
                    "cardTone" to strProp("Card tone: default, tinted, outlined"),
                    "fontSizeScale" to numProp("Font scale multiplier (0.8 to 1.6)"),
                    "cornerRadiusDp" to intProp("Corner radius in dp (8 to 28)")
                ),
                required = listOf("widgetId")
            )
        )

        declarations.put(
            fn(
                name = "createPage",
                description = "Create a new workspace page/canvas and optionally switch to it.",
                props = mapOf(
                    "title" to strProp("Title of the new page"),
                    "switchToPage" to boolProp("Whether to immediately switch to the new page (default true)")
                ),
                required = listOf("title")
            )
        )

        declarations.put(
            fn(
                name = "deletePage",
                description = "Delete a workspace page by pageId (cannot delete the last remaining page).",
                props = mapOf(
                    "pageId" to strProp("ID of the page to delete")
                ),
                required = listOf("pageId")
            )
        )

        declarations.put(
            fn(
                name = "switchPage",
                description = "Switch active workspace view to an existing pageId.",
                props = mapOf(
                    "pageId" to strProp("ID of the page to activate")
                ),
                required = listOf("pageId")
            )
        )

        declarations.put(
            fn(
                name = "createButton",
                description = "Create a functional interactive Button Widget on the canvas.",
                props = mapOf(
                    "title" to strProp("Widget header title"),
                    "label" to strProp("Button text label"),
                    "actionType" to strProp("Action: increment_counter, start_timer, reset_timer, tap_counter"),
                    "linkedWidgetId" to strProp("Optional target widgetId for the action"),
                    "x" to numProp("Optional X coordinate"),
                    "y" to numProp("Optional Y coordinate"),
                    "accentColor" to strProp("Optional accent color key")
                ),
                required = listOf("title", "label")
            )
        )

        declarations.put(
            fn(
                name = "createText",
                description = "Create a Text Widget on the canvas (headings, labels, quotes, summaries).",
                props = mapOf(
                    "title" to strProp("Title of the text block"),
                    "content" to strProp("Body text content"),
                    "subtitle" to strProp("Optional subtitle"),
                    "x" to numProp("Optional X coordinate"),
                    "y" to numProp("Optional Y coordinate"),
                    "accentColor" to strProp("Optional accent color key")
                ),
                required = listOf("title", "content")
            )
        )

        declarations.put(
            fn(
                name = "createInput",
                description = "Create a persistent Input Widget where the user can type and log entries.",
                props = mapOf(
                    "title" to strProp("Title of the input widget"),
                    "placeholder" to strProp("Placeholder hint text"),
                    "x" to numProp("Optional X coordinate"),
                    "y" to numProp("Optional Y coordinate"),
                    "accentColor" to strProp("Optional accent color key")
                ),
                required = listOf("title")
            )
        )

        declarations.put(
            fn(
                name = "createTimer",
                description = "Create a functional countdown Timer Widget (e.g. Pomodoro 25 minutes = 1500 seconds).",
                props = mapOf(
                    "title" to strProp("Title of the timer, e.g. Pomodoro"),
                    "durationSeconds" to intProp("Countdown duration in seconds (1 to 86400)"),
                    "autoStart" to boolProp("Optional start immediately"),
                    "x" to numProp("Optional X coordinate"),
                    "y" to numProp("Optional Y coordinate"),
                    "accentColor" to strProp("Optional accent color key")
                ),
                required = listOf("title", "durationSeconds")
            )
        )

        declarations.put(
            fn(
                name = "createNotification",
                description = "Schedule an Android reminder notification at a specific time (24h hour & minute), optionally repeating daily.",
                props = mapOf(
                    "title" to strProp("Reminder notification title"),
                    "message" to strProp("Reminder notification message body"),
                    "hour" to intProp("Hour of day in 24-hour format (0 to 23)"),
                    "minute" to intProp("Minute of hour (0 to 59)"),
                    "isDailyRecurring" to boolProp("True if reminder should repeat every day")
                ),
                required = listOf("title", "message", "hour", "minute")
            )
        )

        declarations.put(
            fn(
                name = "deleteNotifications",
                description = "Cancel and delete a specific reminder by notificationId, or all reminders if deleteAll is true.",
                props = mapOf(
                    "notificationId" to strProp("Optional reminder ID to delete"),
                    "deleteAll" to boolProp("Set true to remove all scheduled reminders")
                ),
                required = emptyList()
            )
        )

        declarations.put(
            fn(
                name = "saveData",
                description = "Persist a key-value entry in Personal App's structured local store.",
                props = mapOf(
                    "key" to strProp("Storage key (alphanumeric/underscore, max 64 chars)"),
                    "value" to strProp("String value to store")
                ),
                required = listOf("key", "value")
            )
        )

        declarations.put(
            fn(
                name = "readData",
                description = "Read a stored key-value entry by key (or list all keys if key omitted).",
                props = mapOf(
                    "key" to strProp("Optional storage key to look up")
                ),
                required = emptyList()
            )
        )

        declarations.put(
            fn(
                name = "deleteData",
                description = "Delete a stored key-value entry by key.",
                props = mapOf(
                    "key" to strProp("Storage key to delete")
                ),
                required = listOf("key")
            )
        )

        declarations.put(
            fn(
                name = "addTodoItem",
                description = "Add a new task to an existing Todo Widget.",
                props = mapOf(
                    "widgetId" to strProp("ID of the Todo widget"),
                    "text" to strProp("Task description")
                ),
                required = listOf("widgetId", "text")
            )
        )

        declarations.put(
            fn(
                name = "toggleTodoItem",
                description = "Mark a task completed or uncompleted inside an existing Todo Widget.",
                props = mapOf(
                    "widgetId" to strProp("ID of the Todo widget"),
                    "taskTextOrId" to strProp("Task ID or matching task text"),
                    "completed" to boolProp("Desired completed state")
                ),
                required = listOf("widgetId", "taskTextOrId", "completed")
            )
        )

        declarations.put(
            fn(
                name = "deleteTodoItem",
                description = "Remove a task from an existing Todo Widget.",
                props = mapOf(
                    "widgetId" to strProp("ID of the Todo widget"),
                    "taskTextOrId" to strProp("Task ID or matching task text")
                ),
                required = listOf("widgetId", "taskTextOrId")
            )
        )

        declarations.put(
            fn(
                name = "undoAction",
                description = "Undo the most recent logical workspace action.",
                props = emptyMap(),
                required = emptyList()
            )
        )

        declarations.put(
            fn(
                name = "redoAction",
                description = "Redo the most recently undone workspace action.",
                props = emptyMap(),
                required = emptyList()
            )
        )

        return declarations
    }

    private fun fn(
        name: String,
        description: String,
        props: Map<String, JSONObject>,
        required: List<String>
    ): JSONObject {
        val propertiesObj = JSONObject()
        props.forEach { (k, v) -> propertiesObj.put(k, v) }
        val schema = JSONObject().apply {
            put("type", "OBJECT")
            put("properties", propertiesObj)
            if (required.isNotEmpty()) {
                val reqArr = JSONArray()
                required.forEach { reqArr.put(it) }
                put("required", reqArr)
            }
        }
        return JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", schema)
        }
    }

    private fun strProp(desc: String) = JSONObject().apply {
        put("type", "STRING")
        put("description", desc)
    }

    private fun intProp(desc: String) = JSONObject().apply {
        put("type", "INTEGER")
        put("description", desc)
    }

    private fun numProp(desc: String) = JSONObject().apply {
        put("type", "NUMBER")
        put("description", desc)
    }

    private fun boolProp(desc: String) = JSONObject().apply {
        put("type", "BOOLEAN")
        put("description", desc)
    }

    private fun strArrayProp(desc: String) = JSONObject().apply {
        put("type", "ARRAY")
        put("description", desc)
        put("items", JSONObject().apply { put("type", "STRING") })
    }
}
