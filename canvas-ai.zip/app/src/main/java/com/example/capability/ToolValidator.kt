package com.example.capability

import com.example.domain.model.CardTone
import com.example.domain.model.CanvasWidget
import com.example.domain.model.ReminderConfig
import com.example.domain.model.WidgetStyle
import com.example.domain.model.WidgetType
import com.example.domain.model.WorkspacePage
import org.json.JSONObject

sealed class ValidationOutcome {
    data class Valid(val action: CapabilityAction) : ValidationOutcome()
    data class Rejected(val reason: String) : ValidationOutcome()
}

class ToolValidator {

    fun validate(
        request: ToolCallRequest,
        existingWidgets: List<CanvasWidget>,
        existingPages: List<WorkspacePage>,
        existingReminders: List<ReminderConfig>
    ): ValidationOutcome {
        val toolName = request.name.trim()
        if (toolName !in CapabilityToolRegistry.ALLOWED_TOOL_NAMES) {
            return ValidationOutcome.Rejected("Unsupported or unauthorized tool '$toolName'.")
        }

        val args = runCatching {
            if (request.argsJson.isBlank()) JSONObject() else JSONObject(request.argsJson)
        }.getOrElse {
            return ValidationOutcome.Rejected("Malformed JSON arguments for '$toolName'.")
        }

        return when (toolName) {
            "createWidget" -> validateCreateWidget(args, existingPages)
            "createText" -> validateCreateText(args)
            "createInput" -> validateCreateInput(args)
            "createTimer" -> validateCreateTimer(args)
            "createButton" -> validateCreateButton(args, existingWidgets)
            "updateWidget" -> validateUpdateWidget(args, existingWidgets)
            "deleteWidget" -> validateDeleteWidget(args, existingWidgets)
            "moveWidget" -> validateMoveWidget(args, existingWidgets)
            "resizeWidget" -> validateResizeWidget(args, existingWidgets)
            "changeStyle" -> validateChangeStyle(args, existingWidgets)
            "createPage" -> validateCreatePage(args)
            "deletePage" -> validateDeletePage(args, existingPages)
            "switchPage" -> validateSwitchPage(args, existingPages)
            "createNotification" -> validateCreateNotification(args)
            "deleteNotifications" -> validateDeleteNotifications(args, existingReminders)
            "saveData" -> validateSaveData(args)
            "readData" -> validateReadData(args)
            "deleteData" -> validateDeleteData(args)
            "addTodoItem" -> validateAddTodoItem(args, existingWidgets)
            "toggleTodoItem" -> validateToggleTodoItem(args, existingWidgets)
            "deleteTodoItem" -> validateDeleteTodoItem(args, existingWidgets)
            "undoAction" -> ValidationOutcome.Valid(CapabilityAction.UndoAction)
            "redoAction" -> ValidationOutcome.Valid(CapabilityAction.RedoAction)
            else -> ValidationOutcome.Rejected("Unsupported tool '$toolName'.")
        }
    }

    private fun validateCreateWidget(
        args: JSONObject,
        existingPages: List<WorkspacePage>
    ): ValidationOutcome {
        val rawType = args.optString("type", "").trim()
        val type = WidgetType.fromWireName(rawType)
            ?: return ValidationOutcome.Rejected("Unsupported widget type '$rawType'.")

        val title = sanitizeText(args.optString("title", type.displayName), MAX_TITLE_LEN)
            .ifBlank { type.displayName }

        val pageId = args.optOptionalString("pageId")?.let { pid ->
            if (existingPages.none { it.id == pid }) {
                return ValidationOutcome.Rejected("Unknown pageId '$pid'.")
            }
            pid
        }

        val x = args.optOptionalFloat("x")?.coerceIn(MIN_COORD, MAX_COORD)
        val y = args.optOptionalFloat("y")?.coerceIn(MIN_COORD, MAX_COORD)
        val width = args.optOptionalFloat("width")?.coerceIn(MIN_WIDGET_WIDTH, MAX_WIDGET_WIDTH)
        val height = args.optOptionalFloat("height")?.coerceIn(MIN_WIDGET_HEIGHT, MAX_WIDGET_HEIGHT)
        val accent = args.optOptionalString("accentColor")?.lowercase()?.takeIf { it in WidgetStyle.ALLOWED_ACCENTS }
        val tone = args.optOptionalString("cardTone")?.let { CardTone.fromWireName(it) }

        val itemsArr = args.optJSONArray("items")
        val items = buildList {
            if (itemsArr != null) {
                for (i in 0 until itemsArr.length().coerceAtMost(50)) {
                    val item = sanitizeText(itemsArr.optString(i, ""), 200)
                    if (item.isNotBlank()) add(item)
                }
            }
        }

        val durationSeconds = if (args.has("durationSeconds") && !args.isNull("durationSeconds")) {
            args.optInt("durationSeconds", 1500).coerceIn(1, 86400)
        } else null

        val step = if (args.has("step") && !args.isNull("step")) {
            args.optInt("step", 1).coerceIn(1, 10000)
        } else null

        return ValidationOutcome.Valid(
            CapabilityAction.CreateWidget(
                type = type,
                title = title,
                pageId = pageId,
                x = x,
                y = y,
                width = width,
                height = height,
                accentColor = accent,
                cardTone = tone,
                content = args.optOptionalString("content")?.let { sanitizeText(it, MAX_CONTENT_LEN) },
                subtitle = args.optOptionalString("subtitle")?.let { sanitizeText(it, MAX_TITLE_LEN) },
                items = items,
                durationSeconds = durationSeconds,
                autoStart = args.optBoolean("autoStart", false),
                is24Hour = args.optBoolean("is24Hour", false),
                showSeconds = args.optBoolean("showSeconds", true),
                initialValue = args.optOptionalFloat("initialValue"),
                targetValue = args.optOptionalFloat("targetValue")?.coerceAtLeast(1f),
                step = step,
                unit = args.optOptionalString("unit")?.let { sanitizeText(it, 20) },
                buttonLabel = args.optOptionalString("buttonLabel")?.let { sanitizeText(it, 48) },
                actionType = args.optOptionalString("actionType")?.takeIf {
                    it in setOf("increment_counter", "start_timer", "reset_timer", "tap_counter")
                },
                linkedWidgetId = args.optOptionalString("linkedWidgetId"),
                placeholder = args.optOptionalString("placeholder")?.let { sanitizeText(it, 80) }
            )
        )
    }

    private fun validateCreateText(args: JSONObject): ValidationOutcome {
        val title = sanitizeText(args.optString("title", "Note"), MAX_TITLE_LEN).ifBlank { "Text" }
        val content = sanitizeText(args.optString("content", ""), MAX_CONTENT_LEN)
        return ValidationOutcome.Valid(
            CapabilityAction.CreateWidget(
                type = WidgetType.TEXT,
                title = title,
                pageId = null,
                x = args.optOptionalFloat("x")?.coerceIn(MIN_COORD, MAX_COORD),
                y = args.optOptionalFloat("y")?.coerceIn(MIN_COORD, MAX_COORD),
                width = null,
                height = null,
                accentColor = args.optOptionalString("accentColor")?.lowercase()?.takeIf { it in WidgetStyle.ALLOWED_ACCENTS },
                cardTone = null,
                content = content,
                subtitle = args.optOptionalString("subtitle")?.let { sanitizeText(it, MAX_TITLE_LEN) },
                items = emptyList(),
                durationSeconds = null,
                autoStart = false,
                is24Hour = false,
                showSeconds = true,
                initialValue = null,
                targetValue = null,
                step = null,
                unit = null,
                buttonLabel = null,
                actionType = null,
                linkedWidgetId = null,
                placeholder = null
            )
        )
    }

    private fun validateCreateInput(args: JSONObject): ValidationOutcome {
        val title = sanitizeText(args.optString("title", "Quick Input"), MAX_TITLE_LEN).ifBlank { "Input" }
        val placeholder = sanitizeText(args.optString("placeholder", "Type and save…"), 80)
        return ValidationOutcome.Valid(
            CapabilityAction.CreateWidget(
                type = WidgetType.INPUT,
                title = title,
                pageId = null,
                x = args.optOptionalFloat("x")?.coerceIn(MIN_COORD, MAX_COORD),
                y = args.optOptionalFloat("y")?.coerceIn(MIN_COORD, MAX_COORD),
                width = null,
                height = null,
                accentColor = args.optOptionalString("accentColor")?.lowercase()?.takeIf { it in WidgetStyle.ALLOWED_ACCENTS },
                cardTone = null,
                content = null,
                subtitle = null,
                items = emptyList(),
                durationSeconds = null,
                autoStart = false,
                is24Hour = false,
                showSeconds = true,
                initialValue = null,
                targetValue = null,
                step = null,
                unit = null,
                buttonLabel = null,
                actionType = null,
                linkedWidgetId = null,
                placeholder = placeholder
            )
        )
    }

    private fun validateCreateTimer(args: JSONObject): ValidationOutcome {
        val title = sanitizeText(args.optString("title", "Timer"), MAX_TITLE_LEN).ifBlank { "Timer" }
        val duration = args.optInt("durationSeconds", 1500).coerceIn(1, 86400)
        return ValidationOutcome.Valid(
            CapabilityAction.CreateWidget(
                type = WidgetType.TIMER,
                title = title,
                pageId = null,
                x = args.optOptionalFloat("x")?.coerceIn(MIN_COORD, MAX_COORD),
                y = args.optOptionalFloat("y")?.coerceIn(MIN_COORD, MAX_COORD),
                width = null,
                height = null,
                accentColor = args.optOptionalString("accentColor")?.lowercase()?.takeIf { it in WidgetStyle.ALLOWED_ACCENTS },
                cardTone = null,
                content = null,
                subtitle = null,
                items = emptyList(),
                durationSeconds = duration,
                autoStart = args.optBoolean("autoStart", false),
                is24Hour = false,
                showSeconds = true,
                initialValue = null,
                targetValue = null,
                step = null,
                unit = null,
                buttonLabel = null,
                actionType = null,
                linkedWidgetId = null,
                placeholder = null
            )
        )
    }

    private fun validateCreateButton(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val title = sanitizeText(args.optString("title", "Action"), MAX_TITLE_LEN).ifBlank { "Action" }
        val label = sanitizeText(args.optString("label", "Tap"), 48).ifBlank { "Tap" }
        val linkedId = args.optOptionalString("linkedWidgetId")?.also { id ->
            if (existingWidgets.none { it.id == id }) {
                return ValidationOutcome.Rejected("Linked widget '$id' not found.")
            }
        }
        val actionType = args.optOptionalString("actionType")?.takeIf {
            it in setOf("increment_counter", "start_timer", "reset_timer", "tap_counter")
        } ?: "tap_counter"

        return ValidationOutcome.Valid(
            CapabilityAction.CreateWidget(
                type = WidgetType.BUTTON,
                title = title,
                pageId = null,
                x = args.optOptionalFloat("x")?.coerceIn(MIN_COORD, MAX_COORD),
                y = args.optOptionalFloat("y")?.coerceIn(MIN_COORD, MAX_COORD),
                width = null,
                height = null,
                accentColor = args.optOptionalString("accentColor")?.lowercase()?.takeIf { it in WidgetStyle.ALLOWED_ACCENTS },
                cardTone = null,
                content = null,
                subtitle = null,
                items = emptyList(),
                durationSeconds = null,
                autoStart = false,
                is24Hour = false,
                showSeconds = true,
                initialValue = null,
                targetValue = null,
                step = null,
                unit = null,
                buttonLabel = label,
                actionType = actionType,
                linkedWidgetId = linkedId,
                placeholder = null
            )
        )
    }

    private fun validateUpdateWidget(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        if (existingWidgets.none { it.id == widgetId }) {
            return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        }
        val timerAction = args.optOptionalString("timerAction")?.lowercase()?.takeIf {
            it in setOf("start", "pause", "reset")
        }
        val duration = if (args.has("durationSeconds") && !args.isNull("durationSeconds")) {
            args.optInt("durationSeconds", 1500).coerceIn(1, 86400)
        } else null
        val counterVal = if (args.has("counterValue") && !args.isNull("counterValue")) {
            args.optInt("counterValue", 0)
        } else null
        val is24 = if (args.has("is24Hour") && !args.isNull("is24Hour")) {
            args.optBoolean("is24Hour")
        } else null

        return ValidationOutcome.Valid(
            CapabilityAction.UpdateWidget(
                widgetId = widgetId,
                title = args.optOptionalString("title")?.let { sanitizeText(it, MAX_TITLE_LEN) },
                content = args.optOptionalString("content")?.let { sanitizeText(it, MAX_CONTENT_LEN) },
                appendContent = args.optBoolean("appendContent", false),
                subtitle = args.optOptionalString("subtitle")?.let { sanitizeText(it, MAX_TITLE_LEN) },
                durationSeconds = duration,
                timerAction = timerAction,
                counterValue = counterVal,
                progressCurrent = args.optOptionalFloat("progressCurrent")?.coerceAtLeast(0f),
                progressTarget = args.optOptionalFloat("progressTarget")?.coerceAtLeast(1f),
                is24Hour = is24
            )
        )
    }

    private fun validateDeleteWidget(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        if (existingWidgets.none { it.id == widgetId }) {
            return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        }
        return ValidationOutcome.Valid(CapabilityAction.DeleteWidget(widgetId))
    }

    private fun validateMoveWidget(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        if (existingWidgets.none { it.id == widgetId }) {
            return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        }
        val x = args.optOptionalFloat("x")?.coerceIn(MIN_COORD, MAX_COORD)
        val y = args.optOptionalFloat("y")?.coerceIn(MIN_COORD, MAX_COORD)
        val anchor = args.optOptionalString("anchor")?.lowercase()?.replace(" ", "_")?.replace("-", "_")
        if (x == null && y == null && anchor == null) {
            return ValidationOutcome.Rejected("moveWidget requires either x/y coordinates or an anchor.")
        }
        if (anchor != null && anchor !in ALLOWED_ANCHORS) {
            return ValidationOutcome.Rejected("Unsupported anchor '$anchor'.")
        }
        return ValidationOutcome.Valid(CapabilityAction.MoveWidget(widgetId, x, y, anchor))
    }

    private fun validateResizeWidget(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        if (existingWidgets.none { it.id == widgetId }) {
            return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        }
        val width = args.optOptionalFloat("width")?.coerceIn(MIN_WIDGET_WIDTH, MAX_WIDGET_WIDTH)
        val height = args.optOptionalFloat("height")?.coerceIn(MIN_WIDGET_HEIGHT, MAX_WIDGET_HEIGHT)
        val scaleFactor = args.optOptionalFloat("scaleFactor")?.coerceIn(0.5f, 2.5f)
        if (width == null && height == null && scaleFactor == null) {
            return ValidationOutcome.Rejected("resizeWidget requires width, height, or scaleFactor.")
        }
        return ValidationOutcome.Valid(CapabilityAction.ResizeWidget(widgetId, width, height, scaleFactor))
    }

    private fun validateChangeStyle(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        if (existingWidgets.none { it.id == widgetId }) {
            return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        }
        val accent = args.optOptionalString("accentColor")?.lowercase()?.takeIf { it in WidgetStyle.ALLOWED_ACCENTS }
        val tone = args.optOptionalString("cardTone")?.let { CardTone.fromWireName(it) }
        val fontScale = args.optOptionalFloat("fontSizeScale")?.coerceIn(0.75f, 1.8f)
        val radius = if (args.has("cornerRadiusDp") && !args.isNull("cornerRadiusDp")) {
            args.optInt("cornerRadiusDp", 18).coerceIn(8, 28)
        } else null
        return ValidationOutcome.Valid(
            CapabilityAction.ChangeStyle(widgetId, accent, tone, fontScale, radius)
        )
    }

    private fun validateCreatePage(args: JSONObject): ValidationOutcome {
        val title = sanitizeText(args.optString("title", ""), 40)
        if (title.isBlank()) {
            return ValidationOutcome.Rejected("Page title cannot be empty.")
        }
        return ValidationOutcome.Valid(
            CapabilityAction.CreatePage(
                title = title,
                switchToPage = args.optBoolean("switchToPage", true)
            )
        )
    }

    private fun validateDeletePage(
        args: JSONObject,
        existingPages: List<WorkspacePage>
    ): ValidationOutcome {
        val pageId = args.optString("pageId", "").trim()
        if (existingPages.none { it.id == pageId }) {
            return ValidationOutcome.Rejected("Page '$pageId' does not exist.")
        }
        if (existingPages.size <= 1) {
            return ValidationOutcome.Rejected("Cannot delete the only remaining workspace page.")
        }
        return ValidationOutcome.Valid(CapabilityAction.DeletePage(pageId))
    }

    private fun validateSwitchPage(
        args: JSONObject,
        existingPages: List<WorkspacePage>
    ): ValidationOutcome {
        val pageId = args.optString("pageId", "").trim()
        if (existingPages.none { it.id == pageId }) {
            return ValidationOutcome.Rejected("Page '$pageId' does not exist.")
        }
        return ValidationOutcome.Valid(CapabilityAction.SwitchPage(pageId))
    }

    private fun validateCreateNotification(args: JSONObject): ValidationOutcome {
        val title = sanitizeText(args.optString("title", "Reminder"), MAX_TITLE_LEN).ifBlank { "Reminder" }
        val message = sanitizeText(args.optString("message", title), 300).ifBlank { title }
        if (!args.has("hour") || !args.has("minute")) {
            return ValidationOutcome.Rejected("Reminder requires hour (0-23) and minute (0-59).")
        }
        val hour = args.optInt("hour", -1)
        val minute = args.optInt("minute", -1)
        if (hour !in 0..23 || minute !in 0..59) {
            return ValidationOutcome.Rejected("Invalid reminder time $hour:$minute.")
        }
        val recurring = args.optBoolean("isDailyRecurring", false)
        return ValidationOutcome.Valid(
            CapabilityAction.CreateNotification(title, message, hour, minute, recurring)
        )
    }

    private fun validateDeleteNotifications(
        args: JSONObject,
        existingReminders: List<ReminderConfig>
    ): ValidationOutcome {
        val deleteAll = args.optBoolean("deleteAll", false)
        val id = args.optOptionalString("notificationId")
        if (!deleteAll && id == null) {
            return ValidationOutcome.Rejected("Provide notificationId or set deleteAll=true.")
        }
        if (!deleteAll && id != null && existingReminders.none { it.id == id }) {
            return ValidationOutcome.Rejected("Reminder '$id' does not exist.")
        }
        return ValidationOutcome.Valid(CapabilityAction.DeleteNotifications(id, deleteAll))
    }

    private fun validateSaveData(args: JSONObject): ValidationOutcome {
        val rawKey = args.optString("key", "").trim()
        if (rawKey.isBlank() || rawKey.length > 64 || !rawKey.matches(Regex("[a-zA-Z0-9_.-]+"))) {
            return ValidationOutcome.Rejected("Invalid storage key '$rawKey'. Use alphanumeric, _, ., or -.")
        }
        val value = sanitizeText(args.optString("value", ""), 4000)
        return ValidationOutcome.Valid(CapabilityAction.SaveData(rawKey, value))
    }

    private fun validateReadData(args: JSONObject): ValidationOutcome {
        val key = args.optOptionalString("key")?.trim()
        return ValidationOutcome.Valid(CapabilityAction.ReadData(key))
    }

    private fun validateDeleteData(args: JSONObject): ValidationOutcome {
        val key = args.optString("key", "").trim()
        if (key.isBlank()) return ValidationOutcome.Rejected("Storage key is required.")
        return ValidationOutcome.Valid(CapabilityAction.DeleteData(key))
    }

    private fun validateAddTodoItem(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        val widget = existingWidgets.firstOrNull { it.id == widgetId }
            ?: return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        if (widget.type != WidgetType.TODO) {
            return ValidationOutcome.Rejected("Widget '$widgetId' is not a Todo widget.")
        }
        val text = sanitizeText(args.optString("text", ""), 200)
        if (text.isBlank()) return ValidationOutcome.Rejected("Todo task text cannot be empty.")
        return ValidationOutcome.Valid(CapabilityAction.AddTodoItem(widgetId, text))
    }

    private fun validateToggleTodoItem(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        val widget = existingWidgets.firstOrNull { it.id == widgetId }
            ?: return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        if (widget.type != WidgetType.TODO) {
            return ValidationOutcome.Rejected("Widget '$widgetId' is not a Todo widget.")
        }
        val match = sanitizeText(args.optString("taskTextOrId", ""), 200)
        if (match.isBlank()) return ValidationOutcome.Rejected("taskTextOrId is required.")
        val completed = args.optBoolean("completed", true)
        return ValidationOutcome.Valid(CapabilityAction.ToggleTodoItem(widgetId, match, completed))
    }

    private fun validateDeleteTodoItem(
        args: JSONObject,
        existingWidgets: List<CanvasWidget>
    ): ValidationOutcome {
        val widgetId = args.optString("widgetId", "").trim()
        val widget = existingWidgets.firstOrNull { it.id == widgetId }
            ?: return ValidationOutcome.Rejected("Widget '$widgetId' does not exist.")
        if (widget.type != WidgetType.TODO) {
            return ValidationOutcome.Rejected("Widget '$widgetId' is not a Todo widget.")
        }
        val match = sanitizeText(args.optString("taskTextOrId", ""), 200)
        if (match.isBlank()) return ValidationOutcome.Rejected("taskTextOrId is required.")
        return ValidationOutcome.Valid(CapabilityAction.DeleteTodoItem(widgetId, match))
    }

    private fun sanitizeText(raw: String, maxLen: Int): String =
        raw.replace("\u0000", "").trim().take(maxLen)

    private fun JSONObject.optOptionalString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val v = optString(key, "").trim()
        return v.ifBlank { null }
    }

    private fun JSONObject.optOptionalFloat(key: String): Float? {
        if (!has(key) || isNull(key)) return null
        val d = optDouble(key, Double.NaN)
        return if (d.isNaN() || d.isInfinite()) null else d.toFloat()
    }

    companion object {
        const val MIN_COORD = -5000f
        const val MAX_COORD = 5000f
        const val MIN_WIDGET_WIDTH = 160f
        const val MAX_WIDGET_WIDTH = 640f
        const val MIN_WIDGET_HEIGHT = 100f
        const val MAX_WIDGET_HEIGHT = 640f
        private const val MAX_TITLE_LEN = 120
        private const val MAX_CONTENT_LEN = 5000
        private val ALLOWED_ANCHORS = setOf(
            "top_left", "top_right", "center", "bottom_left", "bottom_right", "left", "right", "top", "bottom"
        )
    }
}
