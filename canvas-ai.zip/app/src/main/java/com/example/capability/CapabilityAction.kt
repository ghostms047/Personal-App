package com.example.capability

import com.example.domain.model.CardTone
import com.example.domain.model.WidgetType

data class ToolCallRequest(
    val id: String,
    val name: String,
    val argsJson: String
)

sealed class CapabilityAction {
    data class CreateWidget(
        val type: WidgetType,
        val title: String,
        val pageId: String?,
        val x: Float?,
        val y: Float?,
        val width: Float?,
        val height: Float?,
        val accentColor: String?,
        val cardTone: CardTone?,
        val content: String?,
        val subtitle: String?,
        val items: List<String>,
        val durationSeconds: Int?,
        val autoStart: Boolean,
        val is24Hour: Boolean,
        val showSeconds: Boolean,
        val initialValue: Float?,
        val targetValue: Float?,
        val step: Int?,
        val unit: String?,
        val buttonLabel: String?,
        val actionType: String?,
        val linkedWidgetId: String?,
        val placeholder: String?
    ) : CapabilityAction()

    data class UpdateWidget(
        val widgetId: String,
        val title: String?,
        val content: String?,
        val appendContent: Boolean,
        val subtitle: String?,
        val durationSeconds: Int?,
        val timerAction: String?,
        val counterValue: Int?,
        val progressCurrent: Float?,
        val progressTarget: Float?,
        val is24Hour: Boolean?
    ) : CapabilityAction()

    data class DeleteWidget(val widgetId: String) : CapabilityAction()

    data class MoveWidget(
        val widgetId: String,
        val x: Float?,
        val y: Float?,
        val anchor: String?
    ) : CapabilityAction()

    data class ResizeWidget(
        val widgetId: String,
        val width: Float?,
        val height: Float?,
        val scaleFactor: Float?
    ) : CapabilityAction()

    data class ChangeStyle(
        val widgetId: String,
        val accentColor: String?,
        val cardTone: CardTone?,
        val fontSizeScale: Float?,
        val cornerRadiusDp: Int?
    ) : CapabilityAction()

    data class CreatePage(
        val title: String,
        val switchToPage: Boolean
    ) : CapabilityAction()

    data class DeletePage(val pageId: String) : CapabilityAction()
    data class SwitchPage(val pageId: String) : CapabilityAction()

    data class CreateNotification(
        val title: String,
        val message: String,
        val hour: Int,
        val minute: Int,
        val isDailyRecurring: Boolean
    ) : CapabilityAction()

    data class DeleteNotifications(
        val notificationId: String?,
        val deleteAll: Boolean
    ) : CapabilityAction()

    data class SaveData(val key: String, val value: String) : CapabilityAction()
    data class ReadData(val key: String?) : CapabilityAction()
    data class DeleteData(val key: String) : CapabilityAction()

    data class AddTodoItem(val widgetId: String, val text: String) : CapabilityAction()
    data class ToggleTodoItem(
        val widgetId: String,
        val taskTextOrId: String,
        val completed: Boolean
    ) : CapabilityAction()

    data class DeleteTodoItem(
        val widgetId: String,
        val taskTextOrId: String
    ) : CapabilityAction()

    data object UndoAction : CapabilityAction()
    data object RedoAction : CapabilityAction()
}

data class CanvasViewport(
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val viewportWidthDp: Float = 380f,
    val viewportHeightDp: Float = 720f
)

data class ToolExecutionItemResult(
    val toolName: String,
    val success: Boolean,
    val message: String,
    val payloadJson: String = "{}"
)

data class CapabilityBatchResult(
    val allSucceeded: Boolean,
    val results: List<ToolExecutionItemResult>,
    val summaryForHistory: String?,
    val undoOrRedoPerformed: Boolean = false
)
