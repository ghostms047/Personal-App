package com.example.capability

import com.example.data.repository.WorkspaceRepository
import com.example.domain.model.CardTone
import com.example.domain.model.CanvasWidget
import com.example.domain.model.ReminderConfig
import com.example.domain.model.TodoItem
import com.example.domain.model.WidgetData
import com.example.domain.model.WidgetStyle
import com.example.domain.model.WidgetType
import com.example.domain.model.WorkspacePage
import com.example.domain.model.WorkspaceSnapshot
import com.example.notifications.ReminderScheduler
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class CapabilityEngine(
    private val repository: WorkspaceRepository,
    private val reminderScheduler: ReminderScheduler,
    private val validator: ToolValidator = ToolValidator()
) {

    suspend fun executeToolBatch(
        requests: List<ToolCallRequest>,
        viewport: CanvasViewport,
        logicalSummaryHint: String? = null
    ): CapabilityBatchResult {
        if (requests.isEmpty()) {
            return CapabilityBatchResult(
                allSucceeded = true,
                results = emptyList(),
                summaryForHistory = null
            )
        }

        // Handle pure Undo/Redo calls directly without recording another history entry
        if (requests.size == 1 && requests.first().name == "undoAction") {
            val undone = undoLastAction()
            return CapabilityBatchResult(
                allSucceeded = undone.first,
                results = listOf(ToolExecutionItemResult("undoAction", undone.first, undone.second)),
                summaryForHistory = null,
                undoOrRedoPerformed = undone.first
            )
        }
        if (requests.size == 1 && requests.first().name == "redoAction") {
            val redone = redoLastAction()
            return CapabilityBatchResult(
                allSucceeded = redone.first,
                results = listOf(ToolExecutionItemResult("redoAction", redone.first, redone.second)),
                summaryForHistory = null,
                undoOrRedoPerformed = redone.first
            )
        }

        val beforeSnapshot = repository.captureSnapshot()
        var mutatingChangeOccurred = false
        val results = mutableListOf<ToolExecutionItemResult>()
        val actionLabels = mutableListOf<String>()

        for (req in requests) {
            val currentWidgets = repository.getAllWidgetsOnce()
            val currentPages = repository.getPagesOnce()
            val currentReminders = repository.getRemindersOnce()

            when (val validation = validator.validate(req, currentWidgets, currentPages, currentReminders)) {
                is ValidationOutcome.Rejected -> {
                    results.add(
                        ToolExecutionItemResult(
                            toolName = req.name,
                            success = false,
                            message = validation.reason
                        )
                    )
                }
                is ValidationOutcome.Valid -> {
                    val outcome = executeSingleAction(
                        action = validation.action,
                        toolName = req.name,
                        viewport = viewport
                    )
                    results.add(outcome.result)
                    if (outcome.mutated) {
                        mutatingChangeOccurred = true
                        outcome.historyLabel?.let { actionLabels.add(it) }
                    }
                }
            }
        }

        if (mutatingChangeOccurred) {
            val afterSnapshot = repository.captureSnapshot()
            val summary = logicalSummaryHint?.takeIf { it.isNotBlank() } ?: buildSummary(actionLabels)
            repository.recordHistoryEntry(summary, beforeSnapshot, afterSnapshot)
        }

        return CapabilityBatchResult(
            allSucceeded = results.all { it.success },
            results = results,
            summaryForHistory = if (mutatingChangeOccurred) buildSummary(actionLabels) else null
        )
    }

    suspend fun undoLastAction(): Pair<Boolean, String> {
        val entry = repository.getLatestUndoableAction()
            ?: return false to "Nothing left to undo."
        val beforeSnapshot = WorkspaceSnapshot.fromJson(entry.beforeSnapshotJson)
            ?: return false to "Could not restore previous workspace state."
        val currentReminders = repository.getRemindersOnce()
        reminderScheduler.cancelAll(currentReminders)
        repository.restoreSnapshot(beforeSnapshot)
        beforeSnapshot.reminders.filter { it.enabled }.forEach {
            reminderScheduler.scheduleReminder(it)
        }
        repository.markHistoryUndone(entry.id, isUndone = true)
        return true to "Undid: ${entry.summary}"
    }

    suspend fun redoLastAction(): Pair<Boolean, String> {
        val entry = repository.getOldestRedoableAction()
            ?: return false to "Nothing left to redo."
        val afterSnapshot = WorkspaceSnapshot.fromJson(entry.afterSnapshotJson)
            ?: return false to "Could not restore undone workspace state."
        val currentReminders = repository.getRemindersOnce()
        reminderScheduler.cancelAll(currentReminders)
        repository.restoreSnapshot(afterSnapshot)
        afterSnapshot.reminders.filter { it.enabled }.forEach {
            reminderScheduler.scheduleReminder(it)
        }
        repository.markHistoryUndone(entry.id, isUndone = false)
        return true to "Redid: ${entry.summary}"
    }

    private data class SingleExecutionOutcome(
        val result: ToolExecutionItemResult,
        val mutated: Boolean,
        val historyLabel: String?
    )

    private suspend fun executeSingleAction(
        action: CapabilityAction,
        toolName: String,
        viewport: CanvasViewport
    ): SingleExecutionOutcome {
        val now = System.currentTimeMillis()
        return when (action) {
            is CapabilityAction.CreateWidget -> {
                val activePageId = action.pageId ?: repository.getActivePageId()
                val existingOnPage = repository.getAllWidgetsOnce().filter { it.pageId == activePageId }
                val (defaultW, defaultH) = defaultSizeFor(action.type)
                val w = action.width ?: defaultW
                val h = action.height ?: defaultH
                val (posX, posY) = if (action.x != null && action.y != null) {
                    action.x to action.y
                } else {
                    findNonOverlappingPosition(existingOnPage, viewport, w, h)
                }
                val maxZ = existingOnPage.maxOfOrNull { it.zIndex } ?: 0
                val widgetId = repository.allocateWidgetId()
                val style = WidgetStyle(
                    accentColorKey = action.accentColor ?: defaultAccentFor(action.type),
                    cardTone = action.cardTone ?: CardTone.DEFAULT
                )
                val data = buildInitialWidgetData(action)
                val widget = CanvasWidget(
                    id = widgetId,
                    pageId = activePageId,
                    type = action.type,
                    title = action.title,
                    x = posX,
                    y = posY,
                    width = w,
                    height = h,
                    zIndex = maxZ + 1,
                    style = style,
                    data = data,
                    createdAt = now,
                    updatedAt = now
                )
                repository.upsertWidget(widget)
                val payload = JSONObject().apply {
                    put("widgetId", widgetId)
                    put("type", widget.type.wireName)
                    put("title", widget.title)
                    put("x", posX.toDouble())
                    put("y", posY.toDouble())
                    put("width", w.toDouble())
                    put("height", h.toDouble())
                }.toString()
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Created ${widget.type.displayName} '${widget.title}' ($widgetId)",
                        payload
                    ),
                    mutated = true,
                    historyLabel = "Created ${widget.type.displayName}: ${widget.title}"
                )
            }

            is CapabilityAction.UpdateWidget -> {
                val widget = repository.getWidget(action.widgetId)
                    ?: return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Widget '${action.widgetId}' not found."),
                        false,
                        null
                    )
                val updatedData = updateWidgetData(widget.data, action, now)
                val updated = widget.copy(
                    title = action.title ?: widget.title,
                    data = updatedData,
                    updatedAt = now
                )
                repository.upsertWidget(updated)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Updated '${updated.title}' (${updated.id})"
                    ),
                    mutated = true,
                    historyLabel = "Updated ${updated.title}"
                )
            }

            is CapabilityAction.DeleteWidget -> {
                val widget = repository.getWidget(action.widgetId)
                repository.deleteWidget(action.widgetId)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Deleted ${widget?.title ?: action.widgetId}"
                    ),
                    mutated = true,
                    historyLabel = "Deleted ${widget?.title ?: action.widgetId}"
                )
            }

            is CapabilityAction.MoveWidget -> {
                val widget = repository.getWidget(action.widgetId)
                    ?: return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Widget not found."),
                        false,
                        null
                    )
                val (newX, newY) = if (action.anchor != null) {
                    computeAnchoredPosition(action.anchor, viewport, widget.width, widget.height)
                } else {
                    (action.x ?: widget.x) to (action.y ?: widget.y)
                }
                val updated = widget.copy(x = newX, y = newY, updatedAt = now)
                repository.upsertWidget(updated)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Moved '${widget.title}' to (${newX.toInt()}, ${newY.toInt()})"
                    ),
                    mutated = true,
                    historyLabel = "Moved ${widget.title}"
                )
            }

            is CapabilityAction.ResizeWidget -> {
                val widget = repository.getWidget(action.widgetId)
                    ?: return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Widget not found."),
                        false,
                        null
                    )
                val newW = when {
                    action.width != null -> action.width
                    action.scaleFactor != null -> (widget.width * action.scaleFactor)
                    else -> widget.width
                }.coerceIn(ToolValidator.MIN_WIDGET_WIDTH, ToolValidator.MAX_WIDGET_WIDTH)

                val newH = when {
                    action.height != null -> action.height
                    action.scaleFactor != null -> (widget.height * action.scaleFactor)
                    else -> widget.height
                }.coerceIn(ToolValidator.MIN_WIDGET_HEIGHT, ToolValidator.MAX_WIDGET_HEIGHT)

                val updated = widget.copy(width = newW, height = newH, updatedAt = now)
                repository.upsertWidget(updated)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Resized '${widget.title}' to ${newW.toInt()}×${newH.toInt()} dp"
                    ),
                    mutated = true,
                    historyLabel = "Resized ${widget.title}"
                )
            }

            is CapabilityAction.ChangeStyle -> {
                val widget = repository.getWidget(action.widgetId)
                    ?: return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Widget not found."),
                        false,
                        null
                    )
                val newStyle = widget.style.copy(
                    accentColorKey = action.accentColor ?: widget.style.accentColorKey,
                    cardTone = action.cardTone ?: widget.style.cardTone,
                    fontSizeScale = action.fontSizeScale ?: widget.style.fontSizeScale,
                    cornerRadiusDp = action.cornerRadiusDp ?: widget.style.cornerRadiusDp
                )
                repository.upsertWidget(widget.copy(style = newStyle, updatedAt = now))
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Styled '${widget.title}'"
                    ),
                    mutated = true,
                    historyLabel = "Styled ${widget.title}"
                )
            }

            is CapabilityAction.CreatePage -> {
                val pages = repository.getPagesOnce()
                val newPageId = repository.allocatePageId()
                val page = WorkspacePage(
                    id = newPageId,
                    title = action.title,
                    sortOrder = (pages.maxOfOrNull { it.sortOrder } ?: 0) + 1,
                    createdAt = now,
                    updatedAt = now
                )
                repository.insertPage(page)
                if (action.switchToPage) {
                    repository.setActivePageId(newPageId)
                }
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Created page '${page.title}' ($newPageId)",
                        JSONObject().put("pageId", newPageId).toString()
                    ),
                    mutated = true,
                    historyLabel = "Created page: ${page.title}"
                )
            }

            is CapabilityAction.DeletePage -> {
                val pages = repository.getPagesOnce()
                val target = pages.firstOrNull { it.id == action.pageId }
                repository.deletePage(action.pageId)
                val remaining = repository.getPagesOnce()
                if (repository.getActivePageId() == action.pageId && remaining.isNotEmpty()) {
                    repository.setActivePageId(remaining.first().id)
                }
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Deleted page '${target?.title ?: action.pageId}'"
                    ),
                    mutated = true,
                    historyLabel = "Deleted page: ${target?.title ?: action.pageId}"
                )
            }

            is CapabilityAction.SwitchPage -> {
                repository.setActivePageId(action.pageId)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Switched to page ${action.pageId}"
                    ),
                    mutated = false,
                    historyLabel = null
                )
            }

            is CapabilityAction.CreateNotification -> {
                val triggerAt = reminderScheduler.computeNextTriggerMillis(action.hour, action.minute)
                val id = "rem_${UUID.randomUUID().toString().take(8)}"
                val reminder = ReminderConfig(
                    id = id,
                    title = action.title,
                    message = action.message,
                    hour = action.hour,
                    minute = action.minute,
                    isDailyRecurring = action.isDailyRecurring,
                    triggerAtMillis = triggerAt,
                    enabled = true,
                    createdAt = now
                )
                repository.upsertReminder(reminder)
                val scheduled = reminderScheduler.scheduleReminder(reminder)
                val timeFormatted = "%02d:%02d".format(action.hour, action.minute)
                val recurrenceLabel = if (action.isDailyRecurring) "daily at $timeFormatted" else "at $timeFormatted"
                val suffix = if (scheduled) "" else " (alarm scheduling restricted by system)"
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(
                        toolName,
                        true,
                        "Scheduled reminder '${action.title}' $recurrenceLabel$suffix",
                        JSONObject().put("notificationId", id).toString()
                    ),
                    mutated = true,
                    historyLabel = "Added reminder: ${action.title}"
                )
            }

            is CapabilityAction.DeleteNotifications -> {
                if (action.deleteAll) {
                    val all = repository.getRemindersOnce()
                    reminderScheduler.cancelAll(all)
                    repository.clearReminders()
                    SingleExecutionOutcome(
                        result = ToolExecutionItemResult(toolName, true, "Deleted all reminders (${all.size})"),
                        mutated = all.isNotEmpty(),
                        historyLabel = "Cleared reminders"
                    )
                } else {
                    val id = action.notificationId!!
                    reminderScheduler.cancelReminder(id)
                    repository.deleteReminder(id)
                    SingleExecutionOutcome(
                        result = ToolExecutionItemResult(toolName, true, "Deleted reminder $id"),
                        mutated = true,
                        historyLabel = "Removed reminder"
                    )
                }
            }

            is CapabilityAction.SaveData -> {
                repository.saveAppData(action.key, action.value)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(toolName, true, "Saved '${action.key}'"),
                    mutated = true,
                    historyLabel = "Saved data: ${action.key}"
                )
            }

            is CapabilityAction.ReadData -> {
                val payload = if (action.key != null) {
                    val found = repository.readAppData(action.key)
                    if (found != null) {
                        JSONObject().put("found", true).put("key", found.key).put("value", found.value).toString()
                    } else {
                        JSONObject().put("found", false).put("key", action.key).toString()
                    }
                } else {
                    val all = repository.getAllAppDataOnce()
                    val arr = JSONArray()
                    all.forEach { arr.put(JSONObject().put("key", it.key).put("value", it.value)) }
                    JSONObject().put("entries", arr).toString()
                }
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(toolName, true, "Read stored data", payload),
                    mutated = false,
                    historyLabel = null
                )
            }

            is CapabilityAction.DeleteData -> {
                repository.deleteAppData(action.key)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(toolName, true, "Deleted data '${action.key}'"),
                    mutated = true,
                    historyLabel = "Deleted data: ${action.key}"
                )
            }

            is CapabilityAction.AddTodoItem -> {
                val widget = repository.getWidget(action.widgetId)
                    ?: return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Widget not found."),
                        false,
                        null
                    )
                val todoData = widget.data as? WidgetData.TodoData ?: WidgetData.TodoData()
                val newItem = TodoItem(text = action.text, completed = false)
                val updated = widget.copy(
                    data = todoData.copy(items = todoData.items + newItem),
                    updatedAt = now
                )
                repository.upsertWidget(updated)
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(toolName, true, "Added '${action.text}' to ${widget.title}"),
                    mutated = true,
                    historyLabel = "Added task to ${widget.title}"
                )
            }

            is CapabilityAction.ToggleTodoItem -> {
                val widget = repository.getWidget(action.widgetId)
                    ?: return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Widget not found."),
                        false,
                        null
                    )
                val todoData = widget.data as? WidgetData.TodoData ?: WidgetData.TodoData()
                val query = action.taskTextOrId.lowercase()
                var matched = false
                val updatedItems = todoData.items.map { item ->
                    if (!matched && (item.id.equals(query, true) || item.text.lowercase().contains(query))) {
                        matched = true
                        item.copy(completed = action.completed)
                    } else item
                }
                if (!matched) {
                    return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Task '${action.taskTextOrId}' not found."),
                        false,
                        null
                    )
                }
                repository.upsertWidget(widget.copy(data = todoData.copy(items = updatedItems), updatedAt = now))
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(toolName, true, "Updated task in ${widget.title}"),
                    mutated = true,
                    historyLabel = "Updated task in ${widget.title}"
                )
            }

            is CapabilityAction.DeleteTodoItem -> {
                val widget = repository.getWidget(action.widgetId)
                    ?: return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Widget not found."),
                        false,
                        null
                    )
                val todoData = widget.data as? WidgetData.TodoData ?: WidgetData.TodoData()
                val query = action.taskTextOrId.lowercase()
                val updatedItems = todoData.items.filterNot { item ->
                    item.id.equals(query, true) || item.text.lowercase().contains(query)
                }
                if (updatedItems.size == todoData.items.size) {
                    return SingleExecutionOutcome(
                        ToolExecutionItemResult(toolName, false, "Task '${action.taskTextOrId}' not found."),
                        false,
                        null
                    )
                }
                repository.upsertWidget(widget.copy(data = todoData.copy(items = updatedItems), updatedAt = now))
                SingleExecutionOutcome(
                    result = ToolExecutionItemResult(toolName, true, "Removed task from ${widget.title}"),
                    mutated = true,
                    historyLabel = "Removed task from ${widget.title}"
                )
            }

            CapabilityAction.UndoAction -> {
                val (ok, msg) = undoLastAction()
                SingleExecutionOutcome(ToolExecutionItemResult(toolName, ok, msg), false, null)
            }

            CapabilityAction.RedoAction -> {
                val (ok, msg) = redoLastAction()
                SingleExecutionOutcome(ToolExecutionItemResult(toolName, ok, msg), false, null)
            }
        }
    }

    private fun buildInitialWidgetData(action: CapabilityAction.CreateWidget): WidgetData {
        return when (action.type) {
            WidgetType.TEXT -> WidgetData.TextData(
                content = action.content ?: "",
                subtitle = action.subtitle ?: ""
            )
            WidgetType.TODO -> WidgetData.TodoData(
                items = action.items.map { TodoItem(text = it, completed = false) }
            )
            WidgetType.NOTES -> WidgetData.NotesData(
                content = action.content ?: ""
            )
            WidgetType.CLOCK -> WidgetData.ClockData(
                is24Hour = action.is24Hour,
                showSeconds = action.showSeconds,
                label = action.subtitle ?: ""
            )
            WidgetType.TIMER -> {
                val dur = action.durationSeconds ?: 1500
                WidgetData.TimerData(
                    durationSeconds = dur,
                    remainingSeconds = dur,
                    isRunning = action.autoStart,
                    lastTickEpochMs = if (action.autoStart) System.currentTimeMillis() else 0L
                )
            }
            WidgetType.COUNTER -> WidgetData.CounterData(
                value = action.initialValue?.toInt() ?: 0,
                step = action.step ?: 1,
                unit = action.unit ?: ""
            )
            WidgetType.BUTTON -> WidgetData.ButtonData(
                label = action.buttonLabel ?: action.title,
                actionType = action.actionType ?: "tap_counter",
                linkedWidgetId = action.linkedWidgetId,
                actionDescription = action.subtitle ?: "",
                tapCount = 0
            )
            WidgetType.PROGRESS -> {
                val target = action.targetValue ?: 100f
                val current = (action.initialValue ?: 0f).coerceIn(0f, target)
                WidgetData.ProgressData(
                    current = current,
                    target = target,
                    unit = action.unit ?: "%"
                )
            }
            WidgetType.INPUT -> WidgetData.InputData(
                placeholder = action.placeholder ?: "Type and save…",
                currentValue = "",
                submittedValues = emptyList()
            )
        }
    }

    private fun updateWidgetData(
        existing: WidgetData,
        action: CapabilityAction.UpdateWidget,
        now: Long
    ): WidgetData {
        return when (existing) {
            is WidgetData.TextData -> existing.copy(
                content = when {
                    action.content == null -> existing.content
                    action.appendContent && existing.content.isNotBlank() -> "${existing.content}\n${action.content}"
                    else -> action.content
                },
                subtitle = action.subtitle ?: existing.subtitle
            )
            is WidgetData.NotesData -> existing.copy(
                content = when {
                    action.content == null -> existing.content
                    action.appendContent && existing.content.isNotBlank() -> "${existing.content}\n${action.content}"
                    else -> action.content
                }
            )
            is WidgetData.ClockData -> existing.copy(
                is24Hour = action.is24Hour ?: existing.is24Hour,
                label = action.subtitle ?: existing.label
            )
            is WidgetData.TimerData -> {
                val newDuration = action.durationSeconds ?: existing.durationSeconds
                when (action.timerAction) {
                    "start" -> existing.copy(
                        durationSeconds = newDuration,
                        remainingSeconds = if (existing.remainingSeconds <= 0) newDuration else existing.remainingSeconds,
                        isRunning = true,
                        lastTickEpochMs = now
                    )
                    "pause" -> existing.copy(isRunning = false, lastTickEpochMs = 0L)
                    "reset" -> existing.copy(
                        durationSeconds = newDuration,
                        remainingSeconds = newDuration,
                        isRunning = false,
                        lastTickEpochMs = 0L
                    )
                    else -> existing.copy(
                        durationSeconds = newDuration,
                        remainingSeconds = newDuration,
                        isRunning = false,
                        lastTickEpochMs = 0L
                    )
                }
            }
            is WidgetData.CounterData -> existing.copy(
                value = action.counterValue ?: existing.value
            )
            is WidgetData.ProgressData -> existing.copy(
                current = action.progressCurrent ?: existing.current,
                target = action.progressTarget ?: existing.target
            )
            else -> existing
        }
    }

    private fun defaultSizeFor(type: WidgetType): Pair<Float, Float> = when (type) {
        WidgetType.TEXT -> 260f to 130f
        WidgetType.TODO -> 280f to 260f
        WidgetType.NOTES -> 280f to 220f
        WidgetType.CLOCK -> 230f to 135f
        WidgetType.TIMER -> 250f to 195f
        WidgetType.COUNTER -> 210f to 150f
        WidgetType.BUTTON -> 200f to 120f
        WidgetType.PROGRESS -> 260f to 155f
        WidgetType.INPUT -> 270f to 190f
    }

    private fun defaultAccentFor(type: WidgetType): String = when (type) {
        WidgetType.TEXT -> "slate"
        WidgetType.TODO -> "cobalt"
        WidgetType.NOTES -> "amber"
        WidgetType.CLOCK -> "slate"
        WidgetType.TIMER -> "sage"
        WidgetType.COUNTER -> "plum"
        WidgetType.BUTTON -> "cobalt"
        WidgetType.PROGRESS -> "sage"
        WidgetType.INPUT -> "cobalt"
    }

    private fun computeAnchoredPosition(
        anchor: String,
        viewport: CanvasViewport,
        w: Float,
        h: Float
    ): Pair<Float, Float> {
        val visibleLeft = -viewport.panX / viewport.zoom
        val visibleTop = -viewport.panY / viewport.zoom
        val visibleW = (viewport.viewportWidthDp / viewport.zoom).coerceAtLeast(320f)
        val visibleH = (viewport.viewportHeightDp / viewport.zoom).coerceAtLeast(480f)
        val margin = 20f
        val topOffset = 84f
        val bottomOffset = 110f

        val leftX = visibleLeft + margin
        val centerX = visibleLeft + (visibleW - w) / 2f
        val rightX = visibleLeft + visibleW - w - margin

        val topY = visibleTop + topOffset
        val centerY = visibleTop + (visibleH - h) / 2f
        val bottomY = visibleTop + visibleH - h - bottomOffset

        return when (anchor) {
            "top_left" -> leftX to topY
            "top_right" -> rightX to topY
            "top" -> centerX to topY
            "left" -> leftX to centerY
            "right" -> rightX to centerY
            "bottom_left" -> leftX to bottomY
            "bottom_right" -> rightX to bottomY
            "bottom" -> centerX to bottomY
            else -> centerX to centerY
        }
    }

    private fun findNonOverlappingPosition(
        existing: List<CanvasWidget>,
        viewport: CanvasViewport,
        w: Float,
        h: Float
    ): Pair<Float, Float> {
        val visibleLeft = -viewport.panX / viewport.zoom
        val visibleTop = -viewport.panY / viewport.zoom
        val startX = visibleLeft + 24f
        val startY = visibleTop + 96f
        val gap = 18f

        for (row in 0..8) {
            for (col in 0..2) {
                val candidateX = startX + col * (w + gap)
                val candidateY = startY + row * (h + gap)
                val overlaps = existing.any { other ->
                    rectsOverlap(
                        candidateX, candidateY, w, h,
                        other.x, other.y, other.width, other.height,
                        padding = 12f
                    )
                }
                if (!overlaps) {
                    return candidateX to candidateY
                }
            }
        }
        return startX to (startY + existing.size * 28f)
    }

    private fun rectsOverlap(
        x1: Float, y1: Float, w1: Float, h1: Float,
        x2: Float, y2: Float, w2: Float, h2: Float,
        padding: Float
    ): Boolean {
        return x1 < x2 + w2 + padding &&
            x1 + w1 + padding > x2 &&
            y1 < y2 + h2 + padding &&
            y1 + h1 + padding > y2
    }

    private fun buildSummary(labels: List<String>): String {
        return when {
            labels.isEmpty() -> "Updated workspace"
            labels.size == 1 -> labels.first()
            else -> "${labels.first()} (+${labels.size - 1} more)"
        }
    }
}
