package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.WorkspaceViewModel
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.PersonalAppTheme
import com.example.ui.welcome.WelcomeScreen
import com.example.ui.workspace.WorkspaceScreen

object AppRoutes {
    const val ROUTE_WELCOME = "welcome"
    const val ROUTE_WORKSPACE = "workspace"
    const val ROUTE_SETTINGS = "settings"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: WorkspaceViewModel = viewModel(
                factory = WorkspaceViewModel.Factory(application)
            )
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val canvasTransform by viewModel.canvasTransform.collectAsStateWithLifecycle()
            val testStatus by viewModel.settingsTestStatus.collectAsStateWithLifecycle()

            PersonalAppTheme(themeMode = uiState.themeMode) {
                if (!uiState.isInitialized) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                } else {
                    val navController = rememberNavController()
                    val startRoute = if (uiState.hasCompletedOnboarding) {
                        AppRoutes.ROUTE_WORKSPACE
                    } else {
                        AppRoutes.ROUTE_WELCOME
                    }

                    NavHost(
                        navController = navController,
                        startDestination = startRoute
                    ) {
                        composable(AppRoutes.ROUTE_WELCOME) {
                            WelcomeScreen(
                                providers = viewModel.getAvailableProviders(),
                                initialProviderId = uiState.aiProviderId,
                                initialModel = uiState.aiModel,
                                testStatus = testStatus,
                                onTestConnection = { providerId, model, key ->
                                    viewModel.testAiConnection(providerId, model, key)
                                },
                                onCompleteSetup = { providerId, model, key ->
                                    viewModel.saveAiConfiguration(
                                        providerId = providerId,
                                        model = model,
                                        apiKeyInput = key,
                                        markOnboardingComplete = true
                                    )
                                    viewModel.clearTestStatus()
                                    navController.navigate(AppRoutes.ROUTE_WORKSPACE) {
                                        popUpTo(AppRoutes.ROUTE_WELCOME) { inclusive = true }
                                    }
                                },
                                onSkipSetup = {
                                    viewModel.completeOnboardingWithoutKey()
                                    viewModel.clearTestStatus()
                                    navController.navigate(AppRoutes.ROUTE_WORKSPACE) {
                                        popUpTo(AppRoutes.ROUTE_WELCOME) { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable(AppRoutes.ROUTE_WORKSPACE) {
                            WorkspaceScreen(
                                uiState = uiState,
                                canvasTransform = canvasTransform,
                                viewModel = viewModel,
                                onOpenSettings = {
                                    viewModel.clearTestStatus()
                                    navController.navigate(AppRoutes.ROUTE_SETTINGS)
                                }
                            )
                        }

                        composable(AppRoutes.ROUTE_SETTINGS) {
                            SettingsScreen(
                                uiState = uiState,
                                providers = viewModel.getAvailableProviders(),
                                testStatus = testStatus,
                                onBack = { navController.popBackStack() },
                                onSaveAiConfig = { providerId, model, newKey ->
                                    viewModel.saveAiConfiguration(providerId, model, newKey)
                                },
                                onClearApiKey = { providerId ->
                                    viewModel.clearSavedApiKey(providerId)
                                },
                                onTestConnection = { providerId, model, pendingKey ->
                                    viewModel.testAiConnection(providerId, model, pendingKey)
                                },
                                onSelectTheme = { mode -> viewModel.setThemeMode(mode) },
                                onToggleNotifications = { enabled ->
                                    viewModel.setNotificationsEnabled(enabled)
                                },
                                onDeleteReminder = { id -> viewModel.deleteReminder(id) },
                                onClearAllData = { viewModel.clearAllLocalData() }
                            )
                        }
                    }
                }
            }
        }
    }
}
