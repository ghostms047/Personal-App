package com.example.data.local.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts AI provider API keys at rest using Android KeyStore (AES-256-GCM)
 * and persists only the ciphertext + IV in private SharedPreferences.
 * Never exposes the plaintext key to UI state.
 */
class SecureCredentialStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _credentialState = MutableStateFlow(computeCredentialSummary())
    val credentialSummaryFlow: StateFlow<CredentialSummary> = _credentialState.asStateFlow()

    fun saveApiKey(providerId: String, rawApiKey: String) {
        val trimmed = rawApiKey.trim()
        if (trimmed.isEmpty()) {
            clearApiKey(providerId)
            return
        }
        val secretKey = getOrCreateSecretKey()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        val iv = cipher.iv
        val encrypted = cipher.doFinal(trimmed.toByteArray(Charsets.UTF_8))

        val last4 = if (trimmed.length >= 4) trimmed.takeLast(4) else "••••"
        prefs.edit()
            .putString(keyCipher(providerId), Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString(keyIv(providerId), Base64.encodeToString(iv, Base64.NO_WRAP))
            .putString(keyHint(providerId), "••••••••$last4")
            .apply()

        _credentialState.value = computeCredentialSummary()
    }

    fun getApiKey(providerId: String): String? {
        val cipherB64 = prefs.getString(keyCipher(providerId), null) ?: return null
        val ivB64 = prefs.getString(keyIv(providerId), null) ?: return null
        return runCatching {
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val iv = Base64.decode(ivB64, Base64.NO_WRAP)
            val encrypted = Base64.decode(cipherB64, Base64.NO_WRAP)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        }.getOrNull()
    }

    fun hasApiKey(providerId: String): Boolean {
        return !prefs.getString(keyCipher(providerId), null).isNullOrEmpty()
    }

    fun getMaskedHint(providerId: String): String {
        return prefs.getString(keyHint(providerId), "") ?: ""
    }

    fun clearApiKey(providerId: String) {
        prefs.edit()
            .remove(keyCipher(providerId))
            .remove(keyIv(providerId))
            .remove(keyHint(providerId))
            .apply()
        _credentialState.value = computeCredentialSummary()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
        _credentialState.value = computeCredentialSummary()
    }

    private fun computeCredentialSummary(): CredentialSummary {
        val hasGemini = hasApiKey("gemini")
        return CredentialSummary(
            hasGeminiKey = hasGemini,
            geminiMaskedHint = if (hasGemini) getMaskedHint("gemini") else ""
        )
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGen.init(spec)
        return keyGen.generateKey()
    }

    private fun keyCipher(providerId: String) = "cipher_$providerId"
    private fun keyIv(providerId: String) = "iv_$providerId"
    private fun keyHint(providerId: String) = "hint_$providerId"

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "personal_app_ai_credentials_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val PREFS_NAME = "personal_app_secure_credentials"
    }
}

data class CredentialSummary(
    val hasGeminiKey: Boolean = false,
    val geminiMaskedHint: String = ""
)
