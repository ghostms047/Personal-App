package com.example.data.repository

import com.example.data.local.db.ActionHistoryEntity
import com.example.data.local.db.AppDataEntity
import com.example.data.local.db.ChatMessageEntity
import com.example.data.local.db.PageEntity
import com.example.data.local.db.PersonalAppDao
import com.example.data.local.db.ReminderEntity
import com.example.data.local.db.WidgetEntity
import com.example.data.local.prefs.UserPreferencesRepository
import com.example.domain.model.ActionHistoryEntry
import com.example.domain.model.CanvasWidget
import com.example.domain.model.ChatMessage
import com.example.domain.model.KeyValueEntry
import com.example.domain.model.ReminderConfig
import com.example.domain.model.WorkspacePage
import com.example.domain.model.WorkspaceSnapshot
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class WorkspaceRepository(
    private val dao: PersonalAppDao,
    private val prefsRepo: UserPreferencesRepository
) {
    val pagesFlow: Flow<List<WorkspacePage>> =
        dao.observePages().map { list -> list.map { it.toDomain() } }

    val widgetsFlow: Flow<List<CanvasWidget>> =
        dao.observeAllWidgets().map { list -> list.mapNotNull { it.toDomain() } }

    val remindersFlow: Flow<List<ReminderConfig>> =
        dao.observeReminders().map { list -> list.map { it.toDomain() } }

    val appDataFlow: Flow<List<KeyValueEntry>> =
        dao.observeAllAppData().map { list -> list.map { it.toDomain() } }

    val actionHistoryFlow: Flow<List<ActionHistoryEntry>> =
        dao.observeActionHistory().map { list -> list.map { it.toDomain() } }

    val chatMessagesFlow: Flow<List<ChatMessage>> =
        dao.observeChatMessages().map { list -> list.map { it.toDomain() } }

    suspend fun ensureDefaultPageExists(): WorkspacePage {
        val pages = dao.getPagesOnce()
        if (pages.isNotEmpty()) {
            val activeId = prefsRepo.getSnapshot().activePageId
            val existing = pages.firstOrNull { it.id == activeId } ?: pages.first()
            if (existing.id != activeId) {
                prefsRepo.setActivePageId(existing.id)
            }
            return existing.toDomain()
        }
        val now = System.currentTimeMillis()
        val mainPage = WorkspacePage(
            id = "page_main",
            title = "Workspace",
            sortOrder = 0,
            createdAt = now,
            updatedAt = now
        )
        dao.insertPage(PageEntity.fromDomain(mainPage))
        prefsRepo.setActivePageId(mainPage.id)
        return mainPage
    }

    suspend fun allocateWidgetId(): String {
        var candidate = prefsRepo.allocateWidgetId()
        while (dao.getWidgetById(candidate) != null) {
            candidate = prefsRepo.allocateWidgetId()
        }
        return candidate
    }

    suspend fun allocatePageId(): String {
        return prefsRepo.allocatePageId()
    }

    suspend fun captureSnapshot(): WorkspaceSnapshot {
        val activePageId = prefsRepo.getSnapshot().activePageId
        return WorkspaceSnapshot(
            pages = dao.getPagesOnce().map { it.toDomain() },
            widgets = dao.getAllWidgetsOnce().mapNotNull { it.toDomain() },
            reminders = dao.getRemindersOnce().map { it.toDomain() },
            keyValueEntries = dao.getAllAppDataOnce().map { it.toDomain() },
            activePageId = activePageId
        )
    }

    suspend fun restoreSnapshot(snapshot: WorkspaceSnapshot) {
        val pages = snapshot.pages.ifEmpty {
            val now = System.currentTimeMillis()
            listOf(WorkspacePage("page_main", "Workspace", 0, now, now))
        }
        dao.replaceWorkspaceState(
            pages = pages.map { PageEntity.fromDomain(it) },
            widgets = snapshot.widgets.map { WidgetEntity.fromDomain(it) },
            reminders = snapshot.reminders.map { ReminderEntity.fromDomain(it) },
            appData = snapshot.keyValueEntries.map { AppDataEntity.fromDomain(it) }
        )
        val validActiveId = pages.firstOrNull { it.id == snapshot.activePageId }?.id ?: pages.first().id
        prefsRepo.setActivePageId(validActiveId)
    }

    suspend fun getWidget(widgetId: String): CanvasWidget? =
        dao.getWidgetById(widgetId)?.toDomain()

    suspend fun getAllWidgetsOnce(): List<CanvasWidget> =
        dao.getAllWidgetsOnce().mapNotNull { it.toDomain() }

    suspend fun getPagesOnce(): List<WorkspacePage> =
        dao.getPagesOnce().map { it.toDomain() }

    suspend fun upsertWidget(widget: CanvasWidget) {
        dao.upsertWidget(WidgetEntity.fromDomain(widget))
    }

    suspend fun deleteWidget(widgetId: String) {
        dao.deleteWidgetById(widgetId)
    }

    suspend fun insertPage(page: WorkspacePage) {
        dao.insertPage(PageEntity.fromDomain(page))
    }

    suspend fun deletePage(pageId: String) {
        dao.deleteWidgetsForPage(pageId)
        dao.deletePageById(pageId)
    }

    suspend fun setActivePageId(pageId: String) {
        prefsRepo.setActivePageId(pageId)
    }

    suspend fun getActivePageId(): String {
        return prefsRepo.getSnapshot().activePageId
    }

    suspend fun upsertReminder(reminder: ReminderConfig) {
        dao.upsertReminder(ReminderEntity.fromDomain(reminder))
    }

    suspend fun getRemindersOnce(): List<ReminderConfig> =
        dao.getRemindersOnce().map { it.toDomain() }

    suspend fun deleteReminder(id: String) {
        dao.deleteReminderById(id)
    }

    suspend fun clearReminders() {
        dao.clearReminders()
    }

    suspend fun saveAppData(key: String, value: String) {
        dao.upsertAppData(AppDataEntity(key = key, value = value, updatedAt = System.currentTimeMillis()))
    }

    suspend fun readAppData(key: String): KeyValueEntry? =
        dao.getAppDataByKey(key)?.toDomain()

    suspend fun getAllAppDataOnce(): List<KeyValueEntry> =
        dao.getAllAppDataOnce().map { it.toDomain() }

    suspend fun deleteAppData(key: String) {
        dao.deleteAppDataByKey(key)
    }

    suspend fun recordHistoryEntry(
        summary: String,
        before: WorkspaceSnapshot,
        after: WorkspaceSnapshot
    ) {
        dao.deleteUndoneHistory()
        dao.insertHistoryEntry(
            ActionHistoryEntity(
                id = UUID.randomUUID().toString(),
                summary = summary,
                timestamp = System.currentTimeMillis(),
                beforeSnapshotJson = before.toJson(),
                afterSnapshotJson = after.toJson(),
                isUndone = false
            )
        )
    }

    suspend fun getLatestUndoableAction(): ActionHistoryEntry? =
        dao.getLatestUndoableAction()?.toDomain()

    suspend fun getOldestRedoableAction(): ActionHistoryEntry? =
        dao.getOldestRedoableAction()?.toDomain()

    suspend fun markHistoryUndone(id: String, isUndone: Boolean) {
        dao.setHistoryUndone(id, isUndone)
    }

    suspend fun appendChatMessage(message: ChatMessage) {
        dao.insertChatMessage(ChatMessageEntity.fromDomain(message))
    }

    suspend fun clearAllWorkspaceData() {
        dao.clearAllWorkspaceData()
        prefsRepo.resetWorkspacePreferences()
        ensureDefaultPageExists()
    }
}
