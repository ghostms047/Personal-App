package com.example.data.local.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "personal_app_prefs")

data class UserPreferences(
    val aiProviderId: String = "gemini",
    val aiModel: String = "gemini-2.5-flash",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val hasCompletedOnboarding: Boolean = false,
    val notificationsEnabled: Boolean = true,
    val activePageId: String = "page_main",
    val nextWidgetSequence: Int = 1,
    val nextPageSequence: Int = 1
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val AI_PROVIDER_ID = stringPreferencesKey("ai_provider_id")
        val AI_MODEL = stringPreferencesKey("ai_model")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val HAS_COMPLETED_ONBOARDING = booleanPreferencesKey("has_completed_onboarding")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val ACTIVE_PAGE_ID = stringPreferencesKey("active_page_id")
        val NEXT_WIDGET_SEQUENCE = intPreferencesKey("next_widget_sequence")
        val NEXT_PAGE_SEQUENCE = intPreferencesKey("next_page_sequence")
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val themeStr = prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name
        val themeMode = runCatching { ThemeMode.valueOf(themeStr) }.getOrDefault(ThemeMode.SYSTEM)
        UserPreferences(
            aiProviderId = prefs[Keys.AI_PROVIDER_ID] ?: "gemini",
            aiModel = prefs[Keys.AI_MODEL] ?: "gemini-2.5-flash",
            themeMode = themeMode,
            hasCompletedOnboarding = prefs[Keys.HAS_COMPLETED_ONBOARDING] ?: false,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            activePageId = prefs[Keys.ACTIVE_PAGE_ID] ?: "page_main",
            nextWidgetSequence = prefs[Keys.NEXT_WIDGET_SEQUENCE] ?: 1,
            nextPageSequence = prefs[Keys.NEXT_PAGE_SEQUENCE] ?: 1
        )
    }

    suspend fun getSnapshot(): UserPreferences = preferencesFlow.first()

    suspend fun setAiProviderAndModel(providerId: String, model: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AI_PROVIDER_ID] = providerId
            prefs[Keys.AI_MODEL] = model
        }
    }

    suspend fun setThemeMode(themeMode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = themeMode.name
        }
    }

    suspend fun setHasCompletedOnboarding(completed: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.HAS_COMPLETED_ONBOARDING] = completed
        }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun setActivePageId(pageId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACTIVE_PAGE_ID] = pageId
        }
    }

    suspend fun allocateWidgetId(): String {
        var allocatedSeq = 1
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.NEXT_WIDGET_SEQUENCE] ?: 1
            allocatedSeq = current
            prefs[Keys.NEXT_WIDGET_SEQUENCE] = current + 1
        }
        return "widget_%03d".format(allocatedSeq)
    }

    suspend fun allocatePageId(): String {
        var allocatedSeq = 1
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.NEXT_PAGE_SEQUENCE] ?: 1
            allocatedSeq = current
            prefs[Keys.NEXT_PAGE_SEQUENCE] = current + 1
        }
        return "page_%03d".format(allocatedSeq)
    }

    suspend fun resetWorkspacePreferences() {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACTIVE_PAGE_ID] = "page_main"
            prefs[Keys.NEXT_WIDGET_SEQUENCE] = 1
            prefs[Keys.NEXT_PAGE_SEQUENCE] = 1
        }
    }
}
