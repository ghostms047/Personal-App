package com.example.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PageEntity::class,
        WidgetEntity::class,
        ReminderEntity::class,
        AppDataEntity::class,
        ActionHistoryEntity::class,
        ChatMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PersonalAppDatabase : RoomDatabase() {
    abstract fun personalAppDao(): PersonalAppDao

    companion object {
        @Volatile
        private var INSTANCE: PersonalAppDatabase? = null

        fun getInstance(context: Context): PersonalAppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PersonalAppDatabase::class.java,
                    "personal_app_workspace.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
