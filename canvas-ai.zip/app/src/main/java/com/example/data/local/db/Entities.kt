package com.example.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.ActionHistoryEntry
import com.example.domain.model.CanvasWidget
import com.example.domain.model.ChatMessage
import com.example.domain.model.ChatRole
import com.example.domain.model.KeyValueEntry
import com.example.domain.model.ReminderConfig
import com.example.domain.model.WidgetData
import com.example.domain.model.WidgetStyle
import com.example.domain.model.WidgetType
import com.example.domain.model.WorkspacePage
import org.json.JSONArray

@Entity(tableName = "pages")
data class PageEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sortOrder: Int,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomain() = WorkspacePage(id, title, sortOrder, createdAt, updatedAt)

    companion object {
        fun fromDomain(page: WorkspacePage) =
            PageEntity(page.id, page.title, page.sortOrder, page.createdAt, page.updatedAt)
    }
}

@Entity(tableName = "widgets")
data class WidgetEntity(
    @PrimaryKey val id: String,
    val pageId: String,
    val type: String,
    val title: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val zIndex: Int,
    val styleJson: String,
    val dataJson: String,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomain(): CanvasWidget? {
        val widgetType = WidgetType.fromWireName(type) ?: return null
        return CanvasWidget(
            id = id,
            pageId = pageId,
            type = widgetType,
            title = title,
            x = x,
            y = y,
            width = width,
            height = height,
            zIndex = zIndex,
            style = WidgetStyle.fromJson(styleJson),
            data = WidgetData.fromJson(widgetType, dataJson),
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    companion object {
        fun fromDomain(widget: CanvasWidget) = WidgetEntity(
            id = widget.id,
            pageId = widget.pageId,
            type = widget.type.wireName,
            title = widget.title,
            x = widget.x,
            y = widget.y,
            width = widget.width,
            height = widget.height,
            zIndex = widget.zIndex,
            styleJson = widget.style.toJson(),
            dataJson = widget.data.toJson(),
            createdAt = widget.createdAt,
            updatedAt = widget.updatedAt
        )
    }
}

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val hour: Int,
    val minute: Int,
    val isDailyRecurring: Boolean,
    val triggerAtMillis: Long,
    val enabled: Boolean,
    val createdAt: Long
) {
    fun toDomain() = ReminderConfig(
        id, title, message, hour, minute, isDailyRecurring, triggerAtMillis, enabled, createdAt
    )

    companion object {
        fun fromDomain(reminder: ReminderConfig) = ReminderEntity(
            reminder.id,
            reminder.title,
            reminder.message,
            reminder.hour,
            reminder.minute,
            reminder.isDailyRecurring,
            reminder.triggerAtMillis,
            reminder.enabled,
            reminder.createdAt
        )
    }
}

@Entity(tableName = "app_data")
data class AppDataEntity(
    @PrimaryKey val key: String,
    val value: String,
    val updatedAt: Long
) {
    fun toDomain() = KeyValueEntry(key, value, updatedAt)

    companion object {
        fun fromDomain(entry: KeyValueEntry) = AppDataEntity(entry.key, entry.value, entry.updatedAt)
    }
}

@Entity(tableName = "action_history")
data class ActionHistoryEntity(
    @PrimaryKey val id: String,
    val summary: String,
    val timestamp: Long,
    val beforeSnapshotJson: String,
    val afterSnapshotJson: String,
    val isUndone: Boolean
) {
    fun toDomain() = ActionHistoryEntry(
        id, summary, timestamp, beforeSnapshotJson, afterSnapshotJson, isUndone
    )

    companion object {
        fun fromDomain(entry: ActionHistoryEntry) = ActionHistoryEntity(
            entry.id,
            entry.summary,
            entry.timestamp,
            entry.beforeSnapshotJson,
            entry.afterSnapshotJson,
            entry.isUndone
        )
    }
}

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val role: String,
    val text: String,
    val toolSummariesJson: String,
    val timestamp: Long
) {
    fun toDomain(): ChatMessage {
        val summaries = runCatching {
            val arr = JSONArray(toolSummariesJson)
            buildList {
                for (i in 0 until arr.length()) {
                    add(arr.getString(i))
                }
            }
        }.getOrDefault(emptyList())
        val parsedRole = runCatching { ChatRole.valueOf(role) }.getOrDefault(ChatRole.SYSTEM)
        return ChatMessage(id, parsedRole, text, summaries, timestamp)
    }

    companion object {
        fun fromDomain(message: ChatMessage): ChatMessageEntity {
            val arr = JSONArray()
            message.toolSummaries.forEach { arr.put(it) }
            return ChatMessageEntity(
                id = message.id,
                role = message.role.name,
                text = message.text,
                toolSummariesJson = arr.toString(),
                timestamp = message.timestamp
            )
        }
    }
}
