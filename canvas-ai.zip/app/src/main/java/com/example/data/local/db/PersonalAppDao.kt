package com.example.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonalAppDao {
    // Pages
    @Query("SELECT * FROM pages ORDER BY sortOrder ASC, createdAt ASC")
    fun observePages(): Flow<List<PageEntity>>

    @Query("SELECT * FROM pages ORDER BY sortOrder ASC, createdAt ASC")
    suspend fun getPagesOnce(): List<PageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPage(page: PageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(pages: List<PageEntity>)

    @Query("DELETE FROM pages WHERE id = :pageId")
    suspend fun deletePageById(pageId: String)

    @Query("DELETE FROM pages")
    suspend fun clearPages()

    // Widgets
    @Query("SELECT * FROM widgets ORDER BY zIndex ASC, createdAt ASC")
    fun observeAllWidgets(): Flow<List<WidgetEntity>>

    @Query("SELECT * FROM widgets WHERE pageId = :pageId ORDER BY zIndex ASC, createdAt ASC")
    fun observeWidgetsForPage(pageId: String): Flow<List<WidgetEntity>>

    @Query("SELECT * FROM widgets ORDER BY zIndex ASC, createdAt ASC")
    suspend fun getAllWidgetsOnce(): List<WidgetEntity>

    @Query("SELECT * FROM widgets WHERE id = :widgetId LIMIT 1")
    suspend fun getWidgetById(widgetId: String): WidgetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWidget(widget: WidgetEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWidgets(widgets: List<WidgetEntity>)

    @Query("DELETE FROM widgets WHERE id = :widgetId")
    suspend fun deleteWidgetById(widgetId: String)

    @Query("DELETE FROM widgets WHERE pageId = :pageId")
    suspend fun deleteWidgetsForPage(pageId: String)

    @Query("DELETE FROM widgets")
    suspend fun clearWidgets()

    // Reminders
    @Query("SELECT * FROM reminders ORDER BY createdAt DESC")
    fun observeReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders ORDER BY createdAt DESC")
    suspend fun getRemindersOnce(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun getReminderById(id: String): ReminderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReminder(reminder: ReminderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReminders(reminders: List<ReminderEntity>)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteReminderById(id: String)

    @Query("DELETE FROM reminders")
    suspend fun clearReminders()

    // Key-Value App Data
    @Query("SELECT * FROM app_data ORDER BY updatedAt DESC")
    fun observeAllAppData(): Flow<List<AppDataEntity>>

    @Query("SELECT * FROM app_data ORDER BY updatedAt DESC")
    suspend fun getAllAppDataOnce(): List<AppDataEntity>

    @Query("SELECT * FROM app_data WHERE `key` = :key LIMIT 1")
    suspend fun getAppDataByKey(key: String): AppDataEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAppData(entry: AppDataEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAppDataList(entries: List<AppDataEntity>)

    @Query("DELETE FROM app_data WHERE `key` = :key")
    suspend fun deleteAppDataByKey(key: String)

    @Query("DELETE FROM app_data")
    suspend fun clearAppData()

    // Action History
    @Query("SELECT * FROM action_history ORDER BY timestamp DESC")
    fun observeActionHistory(): Flow<List<ActionHistoryEntity>>

    @Query("SELECT * FROM action_history WHERE isUndone = 0 ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestUndoableAction(): ActionHistoryEntity?

    @Query("SELECT * FROM action_history WHERE isUndone = 1 ORDER BY timestamp ASC LIMIT 1")
    suspend fun getOldestRedoableAction(): ActionHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistoryEntry(entry: ActionHistoryEntity)

    @Query("UPDATE action_history SET isUndone = :isUndone WHERE id = :id")
    suspend fun setHistoryUndone(id: String, isUndone: Boolean)

    @Query("DELETE FROM action_history WHERE isUndone = 1")
    suspend fun deleteUndoneHistory()

    @Query("DELETE FROM action_history")
    suspend fun clearActionHistory()

    // Chat Messages
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun observeChatMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatMessages()

    @Transaction
    suspend fun replaceWorkspaceState(
        pages: List<PageEntity>,
        widgets: List<WidgetEntity>,
        reminders: List<ReminderEntity>,
        appData: List<AppDataEntity>
    ) {
        clearPages()
        clearWidgets()
        clearReminders()
        clearAppData()
        if (pages.isNotEmpty()) insertPages(pages)
        if (widgets.isNotEmpty()) upsertWidgets(widgets)
        if (reminders.isNotEmpty()) upsertReminders(reminders)
        if (appData.isNotEmpty()) upsertAppDataList(appData)
    }

    @Transaction
    suspend fun clearAllWorkspaceData() {
        clearWidgets()
        clearPages()
        clearReminders()
        clearAppData()
        clearActionHistory()
        clearChatMessages()
    }
}
