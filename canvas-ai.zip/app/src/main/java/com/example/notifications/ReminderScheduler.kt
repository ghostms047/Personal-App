package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.domain.model.ReminderConfig
import java.util.Calendar

class ReminderScheduler(private val context: Context) {

    private val alarmManager: AlarmManager? =
        context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    fun computeNextTriggerMillis(hour: Int, minute: Int, forceNextDay: Boolean = false): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
            set(Calendar.MINUTE, minute.coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (forceNextDay || target.timeInMillis <= now.timeInMillis + 1000L) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }

    fun scheduleReminder(reminder: ReminderConfig): Boolean {
        val manager = alarmManager ?: return false
        if (!reminder.enabled) {
            cancelReminder(reminder.id)
            return true
        }
        ReminderNotificationHelper.ensureChannel(context)

        val triggerAt = if (reminder.triggerAtMillis > System.currentTimeMillis()) {
            reminder.triggerAtMillis
        } else {
            computeNextTriggerMillis(reminder.hour, reminder.minute)
        }

        val pendingIntent = buildPendingIntent(reminder)
        return runCatching {
            val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                manager.canScheduleExactAlarms()
            } else {
                true
            }
            if (canExact) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            }
            true
        }.getOrElse { false }
    }

    fun cancelReminder(reminderId: String) {
        val manager = alarmManager ?: return
        val intent = Intent(context, ReminderAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.hashCode(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            manager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun cancelAll(reminders: List<ReminderConfig>) {
        reminders.forEach { cancelReminder(it.id) }
    }

    private fun buildPendingIntent(reminder: ReminderConfig): PendingIntent {
        val intent = Intent(context, ReminderAlarmReceiver::class.java).apply {
            putExtra(EXTRA_REMINDER_ID, reminder.id)
            putExtra(EXTRA_TITLE, reminder.title)
            putExtra(EXTRA_MESSAGE, reminder.message)
            putExtra(EXTRA_HOUR, reminder.hour)
            putExtra(EXTRA_MINUTE, reminder.minute)
            putExtra(EXTRA_RECURRING, reminder.isDailyRecurring)
        }
        return PendingIntent.getBroadcast(
            context,
            reminder.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object {
        const val EXTRA_REMINDER_ID = "extra_reminder_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_HOUR = "extra_hour"
        const val EXTRA_MINUTE = "extra_minute"
        const val EXTRA_RECURRING = "extra_recurring"
    }
}
