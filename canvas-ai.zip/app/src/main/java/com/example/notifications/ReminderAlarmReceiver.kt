package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.db.PersonalAppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_ID) ?: return
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE) ?: "Reminder"
        val message = intent.getStringExtra(ReminderScheduler.EXTRA_MESSAGE) ?: title
        val hour = intent.getIntExtra(ReminderScheduler.EXTRA_HOUR, 9)
        val minute = intent.getIntExtra(ReminderScheduler.EXTRA_MINUTE, 0)
        val isRecurring = intent.getBooleanExtra(ReminderScheduler.EXTRA_RECURRING, false)

        ReminderNotificationHelper.showReminderNotification(
            context = context,
            reminderId = reminderId,
            title = title,
            message = message
        )

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = PersonalAppDatabase.getInstance(context).personalAppDao()
                val existing = dao.getReminderById(reminderId)?.toDomain()
                if (existing != null && isRecurring && existing.enabled) {
                    val scheduler = ReminderScheduler(context)
                    val nextTrigger = scheduler.computeNextTriggerMillis(hour, minute, forceNextDay = true)
                    val updated = existing.copy(triggerAtMillis = nextTrigger)
                    dao.upsertReminder(com.example.data.local.db.ReminderEntity.fromDomain(updated))
                    scheduler.scheduleReminder(updated)
                } else if (existing != null && !isRecurring) {
                    val updated = existing.copy(enabled = false)
                    dao.upsertReminder(com.example.data.local.db.ReminderEntity.fromDomain(updated))
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
