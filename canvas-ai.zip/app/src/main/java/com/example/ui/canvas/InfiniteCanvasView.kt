package com.example.ui.canvas

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.CanvasWidget
import com.example.ui.CanvasTransformState
import com.example.ui.theme.LocalWorkspacePalette
import com.example.ui.widgets.CanvasWidgetFrame
import com.example.ui.widgets.WidgetContentDispatcher
import com.example.ui.widgets.WidgetInteractionCallbacks

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InfiniteCanvasView(
    widgets: List<CanvasWidget>,
    selectedWidgetIds: Set<String>,
    transform: CanvasTransformState,
    widgetCallbacks: WidgetInteractionCallbacks,
    onViewportMeasured: (widthDp: Float, heightDp: Float) -> Unit,
    onPanZoom: (panDeltaDpX: Float, panDeltaDpY: Float, zoomFactor: Float, centroidDpX: Float, centroidDpY: Float) -> Unit,
    onClearSelection: () -> Unit,
    onSelectWidget: (widgetId: String, toggleMulti: Boolean) -> Unit,
    onMoveWidgetEnd: (widgetId: String, newX: Float, newY: Float) -> Unit,
    onResizeWidgetEnd: (widgetId: String, newWidth: Float, newHeight: Float) -> Unit,
    onQuickSuggestionClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalWorkspacePalette.current
    val density = LocalDensity.current.density

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(palette.canvasBackground)
            .testTag("infinite_canvas")
    ) {
        val widthDp = maxWidth.value
        val heightDp = maxHeight.value

        LaunchedEffect(widthDp, heightDp) {
            onViewportMeasured(widthDp, heightDp)
        }

        // Dot Grid + Pan/Zoom Surface
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { onClearSelection() })
                }
                .pointerInput(density) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        onPanZoom(
                            pan.x / density,
                            pan.y / density,
                            zoom,
                            centroid.x / density,
                            centroid.y / density
                        )
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val spacingPx = 24f * density * transform.zoom
                if (spacingPx >= 8f) {
                    val panPxX = transform.panX * density
                    val panPxY = transform.panY * density
                    val startX = ((panPxX % spacingPx) + spacingPx) % spacingPx
                    val startY = ((panPxY % spacingPx) + spacingPx) % spacingPx
                    val dotRadius = (1.3f * density * transform.zoom.coerceIn(0.6f, 1.4f))

                    var x = startX
                    while (x < size.width) {
                        var y = startY
                        while (y < size.height) {
                            drawCircle(
                                color = palette.canvasDot,
                                radius = dotRadius,
                                center = Offset(x, y)
                            )
                            y += spacingPx
                        }
                        x += spacingPx
                    }

                    // Subtle origin marker at world (0,0)
                    if (panPxX in -20f..(size.width + 20f) && panPxY in -20f..(size.height + 20f)) {
                        drawCircle(
                            color = palette.canvasDot.copy(alpha = 0.9f),
                            radius = 3.5f * density,
                            center = Offset(panPxX, panPxY)
                        )
                    }
                }
            }

            // World-Space Widget Layer
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(0f, 0f)
                        translationX = transform.panX * density
                        translationY = transform.panY * density
                        scaleX = transform.zoom
                        scaleY = transform.zoom
                    }
            ) {
                widgets.forEach { widget ->
                    CanvasWidgetFrame(
                        widget = widget,
                        isSelected = widget.id in selectedWidgetIds,
                        canvasZoom = transform.zoom,
                        densityPxPerDp = density,
                        onSelect = { toggleMulti -> onSelectWidget(widget.id, toggleMulti) },
                        onMoveEnd = { newX, newY -> onMoveWidgetEnd(widget.id, newX, newY) },
                        onResizeEnd = { newW, newH -> onResizeWidgetEnd(widget.id, newW, newH) }
                    ) { currentWidget ->
                        WidgetContentDispatcher(
                            widget = currentWidget,
                            callbacks = widgetCallbacks
                        )
                    }
                }
            }
        }

        // Empty Canvas Hint (only shown when active page has 0 widgets)
        AnimatedVisibility(
            visible = widgets.isEmpty(),
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 32.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = stringResource(R.string.canvas_empty_hint),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Pan, zoom, and arrange widgets anywhere on this infinite workspace.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(18.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val suggestions = listOf(
                        "Create a todo list",
                        "Make a Pomodoro timer",
                        "Build a study dashboard"
                    )
                    suggestions.forEach { prompt ->
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            shadowElevation = 1.dp,
                            modifier = Modifier
                                .clickable { onQuickSuggestionClick(prompt) }
                                .testTag("suggestion_${prompt.lowercase().replace(" ", "_")}")
                        ) {
                            Text(
                                text = prompt,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
