package com.example.ui.workspace

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.notifications.ReminderNotificationHelper
import com.example.ui.CanvasTransformState
import com.example.ui.WorkspaceUiState
import com.example.ui.WorkspaceViewModel
import com.example.ui.canvas.InfiniteCanvasView
import com.example.ui.chat.AiMessageBar
import com.example.ui.widgets.WidgetInteractionCallbacks

@Composable
fun WorkspaceScreen(
    uiState: WorkspaceUiState,
    canvasTransform: CanvasTransformState,
    viewModel: WorkspaceViewModel,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    var showHistorySheet by remember { mutableStateOf(false) }
    var showPagesSheet by remember { mutableStateOf(false) }
    var chatDraft by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Permission state handled gracefully by ReminderNotificationHelper */ }

    // Request POST_NOTIFICATIONS when a reminder is newly created and permission isn't yet granted
    LaunchedEffect(uiState.reminders.size) {
        if (uiState.reminders.isNotEmpty() &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !ReminderNotificationHelper.hasNotificationPermission(context)
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(uiState.transientBannerMessage) {
        val msg = uiState.transientBannerMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.dismissBanner()
    }

    val widgetCallbacks = remember(viewModel) {
        object : WidgetInteractionCallbacks {
            override fun onAddTodo(widgetId: String, text: String) =
                viewModel.addTodoItemDirect(widgetId, text)

            override fun onToggleTodo(widgetId: String, itemId: String) =
                viewModel.toggleTodoItemDirect(widgetId, itemId)

            override fun onDeleteTodo(widgetId: String, itemId: String) =
                viewModel.deleteTodoItemDirect(widgetId, itemId)

            override fun onSaveNote(widgetId: String, title: String, content: String) =
                viewModel.updateNoteDirect(widgetId, title, content)

            override fun onToggleClockFormat(widgetId: String) =
                viewModel.toggleClockFormatDirect(widgetId)

            override fun onToggleTimer(widgetId: String) =
                viewModel.toggleTimerDirect(widgetId)

            override fun onResetTimer(widgetId: String) =
                viewModel.resetTimerDirect(widgetId)

            override fun onAdjustTimerDuration(widgetId: String, deltaSeconds: Int) =
                viewModel.adjustTimerDurationDirect(widgetId, deltaSeconds)

            override fun onAdjustCounter(widgetId: String, deltaMultiplier: Int) =
                viewModel.adjustCounterDirect(widgetId, deltaMultiplier)

            override fun onResetCounter(widgetId: String) =
                viewModel.resetCounterDirect(widgetId)

            override fun onTriggerButton(widgetId: String) =
                viewModel.triggerButtonWidgetDirect(widgetId)

            override fun onAdjustProgress(widgetId: String, delta: Float) =
                viewModel.adjustProgressDirect(widgetId, delta)

            override fun onSubmitInput(widgetId: String, value: String) =
                viewModel.submitInputDirect(widgetId, value)
        }
    }

    val activePage = uiState.pages.firstOrNull { it.id == uiState.activePageId }

    Box(modifier = Modifier.fillMaxSize()) {
        InfiniteCanvasView(
            widgets = uiState.activePageWidgets,
            selectedWidgetIds = uiState.selectedWidgetIds,
            transform = canvasTransform,
            widgetCallbacks = widgetCallbacks,
            onViewportMeasured = { w, h -> viewModel.updateViewportDimensions(w, h) },
            onPanZoom = { dx, dy, zoom, cx, cy ->
                viewModel.panAndZoomCanvas(dx, dy, zoom, cx, cy)
            },
            onClearSelection = { viewModel.clearSelection() },
            onSelectWidget = { id, toggleMulti -> viewModel.selectWidget(id, toggleMulti) },
            onMoveWidgetEnd = { id, x, y ->
                viewModel.moveWidgetFromGesture(id, x, y, recordHistory = true)
            },
            onResizeWidgetEnd = { id, w, h ->
                viewModel.resizeWidgetFromGesture(id, w, h, recordHistory = true)
            },
            onQuickSuggestionClick = { suggestion ->
                viewModel.sendAiPrompt(suggestion)
            }
        )

        Column(
            modifier = Modifier.align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            WorkspaceTopControls(
                activePage = activePage,
                zoom = canvasTransform.zoom,
                canUndo = uiState.canUndo,
                canRedo = uiState.canRedo,
                onOpenPages = { showPagesSheet = true },
                onResetViewport = { viewModel.resetCanvasViewport() },
                onUndo = { viewModel.undoLastAction() },
                onRedo = { viewModel.redoLastAction() },
                onOpenHistory = { showHistorySheet = true },
                onOpenSettings = onOpenSettings
            )

            SelectionContextualBar(
                selectedCount = uiState.selectedWidgetIds.size,
                isMultiSelectMode = uiState.isMultiSelectMode,
                onToggleMultiSelect = { viewModel.toggleMultiSelectMode() },
                onApplyAccent = { accent -> viewModel.styleSelectedWidgets(accent) },
                onBringToFront = { viewModel.bringSelectedToFront() },
                onDeleteSelected = { viewModel.deleteSelectedWidgets() },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(top = 64.dp)
        )

        AiMessageBar(
            messages = uiState.chatMessages,
            isThinking = uiState.isAiThinking,
            lastErrorKind = uiState.lastAiErrorKind,
            draftText = chatDraft,
            onDraftChange = { chatDraft = it },
            onSend = { prompt ->
                viewModel.sendAiPrompt(prompt)
                chatDraft = ""
            },
            onOpenSettings = onOpenSettings,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    if (showHistorySheet) {
        ActionHistorySheet(
            entries = uiState.actionHistory,
            canUndo = uiState.canUndo,
            canRedo = uiState.canRedo,
            onUndo = { viewModel.undoLastAction() },
            onRedo = { viewModel.redoLastAction() },
            onDismiss = { showHistorySheet = false }
        )
    }

    if (showPagesSheet) {
        PagesSheet(
            pages = uiState.pages,
            activePageId = uiState.activePageId,
            onSelectPage = { viewModel.switchPage(it) },
            onCreatePage = { viewModel.createPage(it) },
            onDeletePage = { viewModel.deletePage(it) },
            onDismiss = { showPagesSheet = false }
        )
    }
}
