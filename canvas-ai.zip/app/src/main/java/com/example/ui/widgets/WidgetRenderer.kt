package com.example.ui.widgets

import androidx.compose.runtime.Composable
import com.example.domain.model.CanvasWidget
import com.example.domain.model.WidgetData

interface WidgetInteractionCallbacks {
    fun onAddTodo(widgetId: String, text: String)
    fun onToggleTodo(widgetId: String, itemId: String)
    fun onDeleteTodo(widgetId: String, itemId: String)
    fun onSaveNote(widgetId: String, title: String, content: String)
    fun onToggleClockFormat(widgetId: String)
    fun onToggleTimer(widgetId: String)
    fun onResetTimer(widgetId: String)
    fun onAdjustTimerDuration(widgetId: String, deltaSeconds: Int)
    fun onAdjustCounter(widgetId: String, deltaMultiplier: Int)
    fun onResetCounter(widgetId: String)
    fun onTriggerButton(widgetId: String)
    fun onAdjustProgress(widgetId: String, delta: Float)
    fun onSubmitInput(widgetId: String, value: String)
}

@Composable
fun WidgetContentDispatcher(
    widget: CanvasWidget,
    callbacks: WidgetInteractionCallbacks
) {
    when (val data = widget.data) {
        is WidgetData.TextData -> TextWidgetContent(widget, data)
        is WidgetData.TodoData -> TodoWidgetContent(
            widget = widget,
            data = data,
            onAddTask = { callbacks.onAddTodo(widget.id, it) },
            onToggleTask = { callbacks.onToggleTodo(widget.id, it) },
            onDeleteTask = { callbacks.onDeleteTodo(widget.id, it) }
        )
        is WidgetData.NotesData -> NotesWidgetContent(
            widget = widget,
            data = data,
            onSaveNote = { title, content -> callbacks.onSaveNote(widget.id, title, content) }
        )
        is WidgetData.ClockData -> ClockWidgetContent(
            widget = widget,
            data = data,
            onToggleFormat = { callbacks.onToggleClockFormat(widget.id) }
        )
        is WidgetData.TimerData -> TimerWidgetContent(
            widget = widget,
            data = data,
            onToggleRun = { callbacks.onToggleTimer(widget.id) },
            onReset = { callbacks.onResetTimer(widget.id) },
            onAdjustDuration = { delta -> callbacks.onAdjustTimerDuration(widget.id, delta) }
        )
        is WidgetData.CounterData -> CounterWidgetContent(
            widget = widget,
            data = data,
            onDecrement = { callbacks.onAdjustCounter(widget.id, -1) },
            onIncrement = { callbacks.onAdjustCounter(widget.id, 1) },
            onReset = { callbacks.onResetCounter(widget.id) }
        )
        is WidgetData.ButtonData -> ButtonWidgetContent(
            widget = widget,
            data = data,
            onTap = { callbacks.onTriggerButton(widget.id) }
        )
        is WidgetData.ProgressData -> ProgressWidgetContent(
            widget = widget,
            data = data,
            onDelta = { delta -> callbacks.onAdjustProgress(widget.id, delta) }
        )
        is WidgetData.InputData -> InputWidgetContent(
            widget = widget,
            data = data,
            onSubmit = { value -> callbacks.onSubmitInput(widget.id, value) }
        )
    }
}
