package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.PersonalAppApplication
import com.example.ai.AiConnectionResult
import com.example.ai.AiErrorKind
import com.example.ai.AiProvider
import com.example.capability.CanvasViewport
import com.example.domain.model.ActionHistoryEntry
import com.example.domain.model.CanvasWidget
import com.example.domain.model.ChatMessage
import com.example.domain.model.KeyValueEntry
import com.example.domain.model.ReminderConfig
import com.example.domain.model.TodoItem
import com.example.domain.model.WidgetData
import com.example.domain.model.WidgetStyle
import com.example.domain.model.WorkspacePage
import com.example.notifications.ReminderNotificationHelper
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

data class CanvasTransformState(
    val panX: Float = 0f,
    val panY: Float = 0f,
    val zoom: Float = 1f,
    val viewportWidthDp: Float = 380f,
    val viewportHeightDp: Float = 720f
) {
    fun toViewport() = CanvasViewport(panX, panY, zoom, viewportWidthDp, viewportHeightDp)
}

data class SettingsTestStatus(
    val isTesting: Boolean = false,
    val successMessage: String? = null,
    val errorMessage: String? = null
)

data class WorkspaceUiState(
    val isInitialized: Boolean = false,
    val hasCompletedOnboarding: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val aiProviderId: String = "gemini",
    val aiModel: String = "gemini-2.5-flash",
    val hasApiKey: Boolean = false,
    val maskedApiKeyHint: String = "",
    val notificationsEnabled: Boolean = true,
    val pages: List<WorkspacePage> = emptyList(),
    val activePageId: String = "page_main",
    val activePageWidgets: List<CanvasWidget> = emptyList(),
    val allWidgetsCount: Int = 0,
    val reminders: List<ReminderConfig> = emptyList(),
    val appDataEntries: List<KeyValueEntry> = emptyList(),
    val actionHistory: List<ActionHistoryEntry> = emptyList(),
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val chatMessages: List<ChatMessage> = emptyList(),
    val selectedWidgetIds: Set<String> = emptySet(),
    val isMultiSelectMode: Boolean = false,
    val isAiThinking: Boolean = false,
    val lastAiErrorKind: AiErrorKind? = null,
    val transientBannerMessage: String? = null
)

class WorkspaceViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as PersonalAppApplication).container
    private val repository = container.workspaceRepository
    private val prefsRepo = container.preferencesRepository
    private val credentialStore = container.credentialStore
    private val providerRegistry = container.aiProviderRegistry
    private val capabilityEngine = container.capabilityEngine
    private val orchestrator = container.aiOrchestrator
    private val reminderScheduler = container.reminderScheduler

    private val _selectedWidgetIds = MutableStateFlow<Set<String>>(emptySet())
    private val _isMultiSelectMode = MutableStateFlow(false)
    private val _isAiThinking = MutableStateFlow(false)
    private val _lastAiErrorKind = MutableStateFlow<AiErrorKind?>(null)
    private val _transientBanner = MutableStateFlow<String?>(null)
    private val _isInitialized = MutableStateFlow(false)

    private val _canvasTransform = MutableStateFlow(CanvasTransformState())
    val canvasTransform: StateFlow<CanvasTransformState> = _canvasTransform.asStateFlow()

    private val _settingsTestStatus = MutableStateFlow(SettingsTestStatus())
    val settingsTestStatus: StateFlow<SettingsTestStatus> = _settingsTestStatus.asStateFlow()

    private data class CoreWorkspaceData(
        val pages: List<WorkspacePage>,
        val widgets: List<CanvasWidget>,
        val reminders: List<ReminderConfig>,
        val appData: List<KeyValueEntry>,
        val history: List<ActionHistoryEntry>,
        val chat: List<ChatMessage>
    )

    private val coreDataFlow = combine(
        repository.pagesFlow,
        repository.widgetsFlow,
        repository.remindersFlow,
        repository.appDataFlow,
        repository.actionHistoryFlow
    ) { pages, widgets, reminders, appData, history ->
        CoreWorkspaceData(pages, widgets, reminders, appData, history, emptyList())
    }.combine(repository.chatMessagesFlow) { core, chat ->
        core.copy(chat = chat)
    }

    private val uiInteractionFlow = combine(
        _selectedWidgetIds,
        _isMultiSelectMode,
        _isAiThinking,
        _lastAiErrorKind,
        _transientBanner
    ) { selected, multi, thinking, errKind, banner ->
        InteractionMeta(selected, multi, thinking, errKind, banner)
    }

    private data class InteractionMeta(
        val selectedIds: Set<String>,
        val multiSelect: Boolean,
        val thinking: Boolean,
        val errKind: AiErrorKind?,
        val banner: String?
    )

    val uiState: StateFlow<WorkspaceUiState> = combine(
        prefsRepo.preferencesFlow,
        credentialStore.credentialSummaryFlow,
        coreDataFlow,
        uiInteractionFlow,
        _isInitialized
    ) { prefs, credSummary, core, meta, initialized ->
        val activePageId = core.pages.firstOrNull { it.id == prefs.activePageId }?.id
            ?: core.pages.firstOrNull()?.id
            ?: "page_main"
        val activeWidgets = core.widgets.filter { it.pageId == activePageId }
        val validSelection = meta.selectedIds.filter { selId ->
            activeWidgets.any { it.id == selId }
        }.toSet()

        WorkspaceUiState(
            isInitialized = initialized,
            hasCompletedOnboarding = prefs.hasCompletedOnboarding,
            themeMode = prefs.themeMode,
            aiProviderId = prefs.aiProviderId,
            aiModel = prefs.aiModel,
            hasApiKey = credSummary.hasGeminiKey,
            maskedApiKeyHint = credSummary.geminiMaskedHint,
            notificationsEnabled = prefs.notificationsEnabled,
            pages = core.pages,
            activePageId = activePageId,
            activePageWidgets = activeWidgets,
            allWidgetsCount = core.widgets.size,
            reminders = core.reminders,
            appDataEntries = core.appData,
            actionHistory = core.history,
            canUndo = core.history.any { !it.isUndone },
            canRedo = core.history.any { it.isUndone },
            chatMessages = core.chat,
            selectedWidgetIds = validSelection,
            isMultiSelectMode = meta.multiSelect,
            isAiThinking = meta.thinking,
            lastAiErrorKind = meta.errKind,
            transientBannerMessage = meta.banner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WorkspaceUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureDefaultPageExists()
            reconcileTimersOnStartup()
            _isInitialized.value = true
        }
        startTimerTickerLoop()
    }

    fun getAvailableProviders(): List<AiProvider> = providerRegistry.getAllProviders()

    private suspend fun reconcileTimersOnStartup() {
        val now = System.currentTimeMillis()
        repository.getAllWidgetsOnce().forEach { widget ->
            val timer = widget.data as? WidgetData.TimerData ?: return@forEach
            if (timer.isRunning && timer.lastTickEpochMs > 0L) {
                val elapsed = ((now - timer.lastTickEpochMs) / 1000L).toInt().coerceAtLeast(0)
                val newRemaining = (timer.remainingSeconds - elapsed).coerceAtLeast(0)
                val stillRunning = newRemaining > 0
                repository.upsertWidget(
                    widget.copy(
                        data = timer.copy(
                            remainingSeconds = newRemaining,
                            isRunning = stillRunning,
                            lastTickEpochMs = if (stillRunning) now else 0L
                        ),
                        updatedAt = now
                    )
                )
            }
        }
    }

    private fun startTimerTickerLoop() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                val now = System.currentTimeMillis()
                val runningTimers = uiState.value.activePageWidgets.filter {
                    (it.data as? WidgetData.TimerData)?.isRunning == true
                }
                // Check all pages' running timers via repository periodically if needed
                val allRunning = if (runningTimers.isNotEmpty()) {
                    runningTimers
                } else {
                    repository.getAllWidgetsOnce().filter {
                        (it.data as? WidgetData.TimerData)?.isRunning == true
                    }
                }
                allRunning.forEach { widget ->
                    val timer = widget.data as? WidgetData.TimerData ?: return@forEach
                    val newRem = (timer.remainingSeconds - 1).coerceAtLeast(0)
                    val stillRunning = newRem > 0
                    repository.upsertWidget(
                        widget.copy(
                            data = timer.copy(
                                remainingSeconds = newRem,
                                isRunning = stillRunning,
                                lastTickEpochMs = if (stillRunning) now else 0L
                            ),
                            updatedAt = now
                        )
                    )
                    if (!stillRunning) {
                        ReminderNotificationHelper.showReminderNotification(
                            context = getApplication(),
                            reminderId = "timer_${widget.id}",
                            title = "${widget.title} finished",
                            message = "Your ${widget.title} countdown has completed."
                        )
                        showBanner("${widget.title} completed")
                    }
                }
            }
        }
    }

    fun updateViewportDimensions(widthDp: Float, heightDp: Float) {
        _canvasTransform.update {
            it.copy(viewportWidthDp = widthDp, viewportHeightDp = heightDp)
        }
    }

    fun panAndZoomCanvas(panDeltaX: Float, panDeltaY: Float, zoomFactor: Float, centroidX: Float, centroidY: Float) {
        _canvasTransform.update { current ->
            val oldZoom = current.zoom
            val newZoom = (oldZoom * zoomFactor).coerceIn(0.45f, 2.2f)
            val zoomRatio = newZoom / oldZoom
            val newPanX = (centroidX - (centroidX - current.panX) * zoomRatio + panDeltaX)
                .coerceIn(-4000f, 4000f)
            val newPanY = (centroidY - (centroidY - current.panY) * zoomRatio + panDeltaY)
                .coerceIn(-4000f, 4000f)
            current.copy(panX = newPanX, panY = newPanY, zoom = newZoom)
        }
    }

    fun resetCanvasViewport() {
        _canvasTransform.update { it.copy(panX = 0f, panY = 0f, zoom = 1f) }
    }

    fun selectWidget(widgetId: String, toggleInMulti: Boolean = false) {
        _selectedWidgetIds.update { current ->
            if (_isMultiSelectMode.value || toggleInMulti) {
                if (widgetId in current) current - widgetId else current + widgetId
            } else {
                setOf(widgetId)
            }
        }
    }

    fun clearSelection() {
        _selectedWidgetIds.value = emptySet()
        _isMultiSelectMode.value = false
    }

    fun toggleMultiSelectMode() {
        _isMultiSelectMode.update { next ->
            val enabled = !next
            if (!enabled && _selectedWidgetIds.value.size > 1) {
                _selectedWidgetIds.value = setOf(_selectedWidgetIds.value.last())
            }
            enabled
        }
    }

    fun bringSelectedToFront() {
        val selected = _selectedWidgetIds.value
        if (selected.isEmpty()) return
        viewModelScope.launch {
            val allOnPage = uiState.value.activePageWidgets
            var maxZ = allOnPage.maxOfOrNull { it.zIndex } ?: 0
            selected.forEach { id ->
                val w = repository.getWidget(id) ?: return@forEach
                maxZ += 1
                repository.upsertWidget(w.copy(zIndex = maxZ, updatedAt = System.currentTimeMillis()))
            }
        }
    }

    fun moveWidgetFromGesture(widgetId: String, newX: Float, newY: Float, recordHistory: Boolean) {
        viewModelScope.launch {
            val before = if (recordHistory) repository.captureSnapshot() else null
            val widget = repository.getWidget(widgetId) ?: return@launch
            val clampedX = newX.coerceIn(-5000f, 5000f)
            val clampedY = newY.coerceIn(-5000f, 5000f)
            repository.upsertWidget(
                widget.copy(x = clampedX, y = clampedY, updatedAt = System.currentTimeMillis())
            )
            if (recordHistory && before != null) {
                val after = repository.captureSnapshot()
                repository.recordHistoryEntry("Moved ${widget.title}", before, after)
            }
        }
    }

    fun resizeWidgetFromGesture(widgetId: String, newWidth: Float, newHeight: Float, recordHistory: Boolean) {
        viewModelScope.launch {
            val before = if (recordHistory) repository.captureSnapshot() else null
            val widget = repository.getWidget(widgetId) ?: return@launch
            val w = newWidth.coerceIn(160f, 640f)
            val h = newHeight.coerceIn(100f, 640f)
            repository.upsertWidget(
                widget.copy(width = w, height = h, updatedAt = System.currentTimeMillis())
            )
            if (recordHistory && before != null) {
                val after = repository.captureSnapshot()
                repository.recordHistoryEntry("Resized ${widget.title}", before, after)
            }
        }
    }

    fun deleteSelectedWidgets() {
        val ids = _selectedWidgetIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val before = repository.captureSnapshot()
            ids.forEach { repository.deleteWidget(it) }
            val after = repository.captureSnapshot()
            val label = if (ids.size == 1) "Deleted widget" else "Deleted ${ids.size} widgets"
            repository.recordHistoryEntry(label, before, after)
            _selectedWidgetIds.value = emptySet()
            _isMultiSelectMode.value = false
        }
    }

    fun styleSelectedWidgets(accentColorKey: String) {
        val ids = _selectedWidgetIds.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val before = repository.captureSnapshot()
            ids.forEach { id ->
                val w = repository.getWidget(id) ?: return@forEach
                repository.upsertWidget(
                    w.copy(
                        style = w.style.copy(accentColorKey = accentColorKey),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
            val after = repository.captureSnapshot()
            repository.recordHistoryEntry("Changed widget style", before, after)
        }
    }

    // --- Direct Interactive Widget Operations ---

    fun addTodoItemDirect(widgetId: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val todo = widget.data as? WidgetData.TodoData ?: return@launch
            val updated = widget.copy(
                data = todo.copy(items = todo.items + TodoItem(text = clean)),
                updatedAt = System.currentTimeMillis()
            )
            repository.upsertWidget(updated)
        }
    }

    fun toggleTodoItemDirect(widgetId: String, itemId: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val todo = widget.data as? WidgetData.TodoData ?: return@launch
            val updatedItems = todo.items.map {
                if (it.id == itemId) it.copy(completed = !it.completed) else it
            }
            repository.upsertWidget(
                widget.copy(data = todo.copy(items = updatedItems), updatedAt = System.currentTimeMillis())
            )
        }
    }

    fun deleteTodoItemDirect(widgetId: String, itemId: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val todo = widget.data as? WidgetData.TodoData ?: return@launch
            val updatedItems = todo.items.filterNot { it.id == itemId }
            repository.upsertWidget(
                widget.copy(data = todo.copy(items = updatedItems), updatedAt = System.currentTimeMillis())
            )
        }
    }

    fun updateNoteDirect(widgetId: String, title: String, content: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            if (widget.data is WidgetData.NotesData) {
                repository.upsertWidget(
                    widget.copy(
                        title = title.ifBlank { widget.title },
                        data = WidgetData.NotesData(content = content),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun toggleClockFormatDirect(widgetId: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val clock = widget.data as? WidgetData.ClockData ?: return@launch
            repository.upsertWidget(
                widget.copy(
                    data = clock.copy(is24Hour = !clock.is24Hour),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun toggleTimerDirect(widgetId: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val timer = widget.data as? WidgetData.TimerData ?: return@launch
            val now = System.currentTimeMillis()
            val nextRunning = !timer.isRunning
            val rem = if (nextRunning && timer.remainingSeconds <= 0) timer.durationSeconds else timer.remainingSeconds
            repository.upsertWidget(
                widget.copy(
                    data = timer.copy(
                        remainingSeconds = rem,
                        isRunning = nextRunning,
                        lastTickEpochMs = if (nextRunning) now else 0L
                    ),
                    updatedAt = now
                )
            )
        }
    }

    fun resetTimerDirect(widgetId: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val timer = widget.data as? WidgetData.TimerData ?: return@launch
            repository.upsertWidget(
                widget.copy(
                    data = timer.copy(
                        remainingSeconds = timer.durationSeconds,
                        isRunning = false,
                        lastTickEpochMs = 0L
                    ),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun adjustTimerDurationDirect(widgetId: String, deltaSeconds: Int) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val timer = widget.data as? WidgetData.TimerData ?: return@launch
            val newDur = (timer.durationSeconds + deltaSeconds).coerceIn(60, 86400)
            val newRem = if (timer.isRunning) (timer.remainingSeconds + deltaSeconds).coerceIn(1, newDur) else newDur
            repository.upsertWidget(
                widget.copy(
                    data = timer.copy(durationSeconds = newDur, remainingSeconds = newRem),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun adjustCounterDirect(widgetId: String, deltaMultiplier: Int) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val counter = widget.data as? WidgetData.CounterData ?: return@launch
            val nextVal = counter.value + (counter.step * deltaMultiplier)
            repository.upsertWidget(
                widget.copy(
                    data = counter.copy(value = nextVal),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun resetCounterDirect(widgetId: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val counter = widget.data as? WidgetData.CounterData ?: return@launch
            repository.upsertWidget(
                widget.copy(data = counter.copy(value = 0), updatedAt = System.currentTimeMillis())
            )
        }
    }

    fun adjustProgressDirect(widgetId: String, delta: Float) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val progress = widget.data as? WidgetData.ProgressData ?: return@launch
            val next = (progress.current + delta).coerceIn(0f, progress.target)
            repository.upsertWidget(
                widget.copy(data = progress.copy(current = next), updatedAt = System.currentTimeMillis())
            )
        }
    }

    fun submitInputDirect(widgetId: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val input = widget.data as? WidgetData.InputData ?: return@launch
            val nextEntries = (listOf(clean) + input.submittedValues).take(20)
            repository.upsertWidget(
                widget.copy(
                    data = input.copy(currentValue = "", submittedValues = nextEntries),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun triggerButtonWidgetDirect(widgetId: String) {
        viewModelScope.launch {
            val widget = repository.getWidget(widgetId) ?: return@launch
            val btn = widget.data as? WidgetData.ButtonData ?: return@launch
            val now = System.currentTimeMillis()
            repository.upsertWidget(
                widget.copy(data = btn.copy(tapCount = btn.tapCount + 1), updatedAt = now)
            )
            when (btn.actionType) {
                "increment_counter" -> {
                    val target = btn.linkedWidgetId?.let { repository.getWidget(it) }
                        ?: uiState.value.activePageWidgets.firstOrNull { it.data is WidgetData.CounterData }
                    val counter = target?.data as? WidgetData.CounterData
                    if (target != null && counter != null) {
                        repository.upsertWidget(
                            target.copy(
                                data = counter.copy(value = counter.value + counter.step),
                                updatedAt = now
                            )
                        )
                        showBanner("${target.title}: ${counter.value + counter.step}")
                    }
                }
                "start_timer" -> {
                    val target = btn.linkedWidgetId?.let { repository.getWidget(it) }
                        ?: uiState.value.activePageWidgets.firstOrNull { it.data is WidgetData.TimerData }
                    if (target != null) toggleTimerDirect(target.id)
                }
                "reset_timer" -> {
                    val target = btn.linkedWidgetId?.let { repository.getWidget(it) }
                        ?: uiState.value.activePageWidgets.firstOrNull { it.data is WidgetData.TimerData }
                    if (target != null) resetTimerDirect(target.id)
                }
                else -> showBanner("${btn.label} (${btn.tapCount + 1})")
            }
        }
    }

    // --- AI Chat & History ---

    fun sendAiPrompt(prompt: String) {
        if (_isAiThinking.value) return
        val clean = prompt.trim()
        if (clean.isEmpty()) return

        viewModelScope.launch {
            _isAiThinking.value = true
            _lastAiErrorKind.value = null
            try {
                val result = orchestrator.handleUserPrompt(
                    userText = clean,
                    viewport = _canvasTransform.value.toViewport()
                )
                if (!result.success) {
                    _lastAiErrorKind.value = result.errorKind
                }
            } finally {
                _isAiThinking.value = false
            }
        }
    }

    fun undoLastAction() {
        viewModelScope.launch {
            val (ok, msg) = capabilityEngine.undoLastAction()
            showBanner(msg)
            if (ok) _selectedWidgetIds.value = emptySet()
        }
    }

    fun redoLastAction() {
        viewModelScope.launch {
            val (ok, msg) = capabilityEngine.redoLastAction()
            showBanner(msg)
            if (ok) _selectedWidgetIds.value = emptySet()
        }
    }

    // --- Pages ---

    fun switchPage(pageId: String) {
        viewModelScope.launch {
            repository.setActivePageId(pageId)
            _selectedWidgetIds.value = emptySet()
            _isMultiSelectMode.value = false
            resetCanvasViewport()
        }
    }

    fun createPage(title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val before = repository.captureSnapshot()
            val pages = repository.getPagesOnce()
            val pageId = repository.allocatePageId()
            val now = System.currentTimeMillis()
            repository.insertPage(
                WorkspacePage(
                    id = pageId,
                    title = clean.take(40),
                    sortOrder = (pages.maxOfOrNull { it.sortOrder } ?: 0) + 1,
                    createdAt = now,
                    updatedAt = now
                )
            )
            repository.setActivePageId(pageId)
            val after = repository.captureSnapshot()
            repository.recordHistoryEntry("Created page: $clean", before, after)
            resetCanvasViewport()
        }
    }

    fun deletePage(pageId: String) {
        viewModelScope.launch {
            val pages = repository.getPagesOnce()
            if (pages.size <= 1) {
                showBanner("At least one page is required.")
                return@launch
            }
            val before = repository.captureSnapshot()
            val target = pages.firstOrNull { it.id == pageId }
            repository.deletePage(pageId)
            val remaining = repository.getPagesOnce()
            if (remaining.isNotEmpty()) {
                repository.setActivePageId(remaining.first().id)
            }
            val after = repository.captureSnapshot()
            repository.recordHistoryEntry("Deleted page: ${target?.title ?: pageId}", before, after)
            resetCanvasViewport()
        }
    }

    // --- Reminders ---

    fun deleteReminder(reminderId: String) {
        viewModelScope.launch {
            val before = repository.captureSnapshot()
            reminderScheduler.cancelReminder(reminderId)
            repository.deleteReminder(reminderId)
            val after = repository.captureSnapshot()
            repository.recordHistoryEntry("Deleted reminder", before, after)
        }
    }

    // --- Onboarding & Settings ---

    fun saveAiConfiguration(
        providerId: String,
        model: String,
        apiKeyInput: String?,
        markOnboardingComplete: Boolean = false
    ) {
        viewModelScope.launch {
            prefsRepo.setAiProviderAndModel(providerId, model.trim().ifBlank { "gemini-2.5-flash" })
            if (!apiKeyInput.isNullOrBlank()) {
                credentialStore.saveApiKey(providerId, apiKeyInput)
            }
            if (markOnboardingComplete) {
                prefsRepo.setHasCompletedOnboarding(true)
            }
            _lastAiErrorKind.value = null
        }
    }

    fun completeOnboardingWithoutKey() {
        viewModelScope.launch {
            prefsRepo.setHasCompletedOnboarding(true)
        }
    }

    fun clearSavedApiKey(providerId: String) {
        credentialStore.clearApiKey(providerId)
        _settingsTestStatus.value = SettingsTestStatus()
    }

    fun testAiConnection(providerId: String, model: String, pendingApiKeyInput: String) {
        viewModelScope.launch {
            _settingsTestStatus.value = SettingsTestStatus(isTesting = true)
            val keyToTest = pendingApiKeyInput.trim().ifBlank {
                credentialStore.getApiKey(providerId).orEmpty()
            }
            val provider = providerRegistry.getProvider(providerId)
            when (val res = provider.testConnection(keyToTest, model)) {
                is AiConnectionResult.Success -> {
                    _settingsTestStatus.value = SettingsTestStatus(
                        isTesting = false,
                        successMessage = "Connected to ${res.modelId} (${res.latencyMs} ms)"
                    )
                }
                is AiConnectionResult.Failure -> {
                    _settingsTestStatus.value = SettingsTestStatus(
                        isTesting = false,
                        errorMessage = res.message
                    )
                }
            }
        }
    }

    fun clearTestStatus() {
        _settingsTestStatus.value = SettingsTestStatus()
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            prefsRepo.setThemeMode(mode)
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setNotificationsEnabled(enabled)
        }
    }

    fun clearAllLocalData() {
        viewModelScope.launch {
            val allReminders = repository.getRemindersOnce()
            reminderScheduler.cancelAll(allReminders)
            repository.clearAllWorkspaceData()
            _selectedWidgetIds.value = emptySet()
            _isMultiSelectMode.value = false
            resetCanvasViewport()
            showBanner("Workspace data cleared")
        }
    }

    fun dismissBanner() {
        _transientBanner.value = null
    }

    private fun showBanner(message: String) {
        _transientBanner.value = message
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
            return WorkspaceViewModel(application) as T
        }
    }
}
