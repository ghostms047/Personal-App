package com.example.ui.widgets

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CanvasWidget
import com.example.domain.model.WidgetData
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.LocalWorkspacePalette
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TextWidgetContent(
    widget: CanvasWidget,
    data: WidgetData.TextData
) {
    val scale = widget.style.fontSizeScale
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center
    ) {
        if (data.subtitle.isNotBlank()) {
            Text(
                text = data.subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
        }
        Text(
            text = data.content.ifBlank { widget.title },
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = (15f * scale).sp,
                lineHeight = (22f * scale).sp
            ),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun NotesWidgetContent(
    widget: CanvasWidget,
    data: WidgetData.NotesData,
    onSaveNote: (title: String, content: String) -> Unit
) {
    var isEditing by remember(widget.id) { mutableStateOf(false) }
    var draftContent by remember(widget.id, data.content) { mutableStateOf(data.content) }
    val accent = LocalWorkspacePalette.current.accentForKey(widget.style.accentColorKey)

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isEditing) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = accent.container,
                    modifier = Modifier
                        .clickable {
                            onSaveNote(widget.title, draftContent)
                            isEditing = false
                        }
                        .testTag("save_note_${widget.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Check,
                            contentDescription = "Save note",
                            tint = accent.accent,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Save",
                            style = MaterialTheme.typography.labelMedium,
                            color = accent.accent
                        )
                    }
                }
            } else {
                IconButton(
                    onClick = { isEditing = true },
                    modifier = Modifier
                        .size(28.dp)
                        .testTag("edit_note_${widget.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Edit,
                        contentDescription = "Edit note",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (isEditing) {
            BasicTextField(
                value = draftContent,
                onValueChange = {
                    draftContent = it
                    onSaveNote(widget.title, it)
                },
                textStyle = TextStyle(
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = (14f * widget.style.fontSizeScale).sp,
                    lineHeight = (20f * widget.style.fontSizeScale).sp
                ),
                cursorBrush = SolidColor(accent.accent),
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(10.dp)
                    .testTag("note_editor_${widget.id}")
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { isEditing = true }
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = data.content.ifBlank { "Tap to write a note…" },
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = (14f * widget.style.fontSizeScale).sp
                    ),
                    color = if (data.content.isBlank()) {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    }
                )
            }
        }
    }
}

@Composable
fun ClockWidgetContent(
    widget: CanvasWidget,
    data: WidgetData.ClockData,
    onToggleFormat: () -> Unit
) {
    var nowMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val timePattern = when {
        data.is24Hour && data.showSeconds -> "HH:mm:ss"
        data.is24Hour && !data.showSeconds -> "HH:mm"
        !data.is24Hour && data.showSeconds -> "hh:mm:ss a"
        else -> "hh:mm a"
    }
    val timeText = remember(nowMillis, timePattern) {
        SimpleDateFormat(timePattern, Locale.getDefault()).format(Date(nowMillis))
    }
    val dateText = remember(nowMillis / 60_000L) {
        SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(nowMillis))
    }
    val accent = LocalWorkspacePalette.current.accentForKey(widget.style.accentColorKey)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onToggleFormat() },
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = dateText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = accent.container
            ) {
                Text(
                    text = if (data.is24Hour) "24H" else "12H",
                    style = MaterialTheme.typography.labelSmall,
                    color = accent.accent,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = timeText,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = JetBrainsMono,
                fontWeight = FontWeight.SemiBold,
                fontSize = (24f * widget.style.fontSizeScale).sp
            ),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun CounterWidgetContent(
    widget: CanvasWidget,
    data: WidgetData.CounterData,
    onDecrement: () -> Unit,
    onIncrement: () -> Unit,
    onReset: () -> Unit
) {
    val accent = LocalWorkspacePalette.current.accentForKey(widget.style.accentColorKey)
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = data.value.toString(),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontFamily = JetBrainsMono,
                    fontSize = (32f * widget.style.fontSizeScale).sp
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
            if (data.unit.isNotBlank()) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = data.unit,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalIconButton(
                onClick = onDecrement,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("counter_dec_${widget.id}")
            ) {
                Icon(Icons.Filled.Remove, contentDescription = "Decrease")
            }
            IconButton(
                onClick = onReset,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    Icons.Outlined.Refresh,
                    contentDescription = "Reset counter",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
            FilledTonalIconButton(
                onClick = onIncrement,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("counter_inc_${widget.id}")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Increase", tint = accent.accent)
            }
        }
    }
}

@Composable
fun ButtonWidgetContent(
    widget: CanvasWidget,
    data: WidgetData.ButtonData,
    onTap: () -> Unit
) {
    val accent = LocalWorkspacePalette.current.accentForKey(widget.style.accentColorKey)
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(
            onClick = onTap,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent.accent),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("widget_button_${widget.id}")
        ) {
            Text(
                text = data.label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (data.tapCount > 0) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${data.tapCount} taps",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ProgressWidgetContent(
    widget: CanvasWidget,
    data: WidgetData.ProgressData,
    onDelta: (Float) -> Unit
) {
    val accent = LocalWorkspacePalette.current.accentForKey(widget.style.accentColorKey)
    val fraction = (data.current / data.target.coerceAtLeast(1f)).coerceIn(0f, 1f)
    val animatedFraction by animateFloatAsState(targetValue = fraction, label = "progressFill")
    val step = if (data.target <= 20f) 1f else (data.target / 10f).coerceAtLeast(1f)

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${formatNum(data.current)} / ${formatNum(data.target)} ${data.unit}".trim(),
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMono),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${(fraction * 100).toInt()}%",
                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMono),
                color = accent.accent
            )
        }

        LinearProgressIndicator(
            progress = { animatedFraction },
            color = accent.accent,
            trackColor = accent.container,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            FilledTonalIconButton(
                onClick = { onDelta(-step) },
                modifier = Modifier.size(34.dp)
            ) {
                Icon(Icons.Filled.Remove, contentDescription = "Decrease progress", modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
            FilledTonalIconButton(
                onClick = { onDelta(step) },
                modifier = Modifier.size(34.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Increase progress", modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun InputWidgetContent(
    widget: CanvasWidget,
    data: WidgetData.InputData,
    onSubmit: (String) -> Unit
) {
    var text by remember(widget.id) { mutableStateOf("") }
    val accent = LocalWorkspacePalette.current.accentForKey(widget.style.accentColorKey)

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = {
                    Text(
                        text = data.placeholder,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .weight(1f)
                    .testTag("input_field_${widget.id}")
            )
            Spacer(modifier = Modifier.width(6.dp))
            FilledTonalIconButton(
                onClick = {
                    if (text.isNotBlank()) {
                        onSubmit(text)
                        text = ""
                    }
                },
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Outlined.Send, contentDescription = "Save input", tint = accent.accent)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(data.submittedValues) { entry ->
                Text(
                    text = "• $entry",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 2.dp),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private fun formatNum(value: Float): String {
    return if (value == value.toInt().toFloat()) value.toInt().toString()
    else String.format(Locale.getDefault(), "%.1f", value)
}
