package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class ThemeMode {
    SYSTEM, LIGHT, DARK
}

data class WidgetAccentColors(
    val accent: Color,
    val container: Color
)

data class WorkspacePalette(
    val canvasBackground: Color,
    val canvasDot: Color,
    val isDark: Boolean
) {
    fun accentForKey(key: String): WidgetAccentColors = when (key.lowercase()) {
        "cobalt", "blue" -> if (isDark) WidgetAccentColors(AccentCobaltDark, AccentCobaltContainerDark)
        else WidgetAccentColors(AccentCobalt, AccentCobaltContainerLight)
        "sage", "teal", "green" -> if (isDark) WidgetAccentColors(AccentSageDark, AccentSageContainerDark)
        else WidgetAccentColors(AccentSage, AccentSageContainerLight)
        "amber", "orange", "gold" -> if (isDark) WidgetAccentColors(AccentAmberDark, AccentAmberContainerDark)
        else WidgetAccentColors(AccentAmber, AccentAmberContainerLight)
        "plum", "purple", "violet" -> if (isDark) WidgetAccentColors(AccentPlumDark, AccentPlumContainerDark)
        else WidgetAccentColors(AccentPlum, AccentPlumContainerLight)
        "terracotta", "red", "rose" -> if (isDark) WidgetAccentColors(AccentTerracottaDark, AccentTerracottaContainerDark)
        else WidgetAccentColors(AccentTerracotta, AccentTerracottaContainerLight)
        else -> if (isDark) WidgetAccentColors(AccentSlateDark, AccentSlateContainerDark)
        else WidgetAccentColors(AccentSlate, AccentSlateContainerLight)
    }
}

val LocalWorkspacePalette = staticCompositionLocalOf {
    WorkspacePalette(
        canvasBackground = CanvasBackgroundLight,
        canvasDot = CanvasDotLight,
        isDark = false
    )
}

private val LightColorScheme = lightColorScheme(
    primary = AccentCobalt,
    onPrimary = Color.White,
    primaryContainer = AccentCobaltContainerLight,
    onPrimaryContainer = AccentCobalt,
    secondary = AccentSage,
    onSecondary = Color.White,
    secondaryContainer = AccentSageContainerLight,
    onSecondaryContainer = AccentSage,
    tertiary = AccentAmber,
    onTertiary = Color.White,
    tertiaryContainer = AccentAmberContainerLight,
    onTertiaryContainer = AccentAmber,
    background = CanvasBackgroundLight,
    onBackground = InkPrimaryLight,
    surface = SurfaceWhite,
    onSurface = InkPrimaryLight,
    surfaceVariant = SurfaceMutedLight,
    onSurfaceVariant = InkSecondaryLight,
    outline = OutlineLight,
    outlineVariant = OutlineLight,
    error = AccentTerracotta,
    onError = Color.White,
    errorContainer = AccentTerracottaContainerLight,
    onErrorContainer = AccentTerracotta
)

private val DarkColorScheme = darkColorScheme(
    primary = AccentCobaltDark,
    onPrimary = Color(0xFF0B1536),
    primaryContainer = AccentCobaltContainerDark,
    onPrimaryContainer = AccentCobaltDark,
    secondary = AccentSageDark,
    onSecondary = Color(0xFF062523),
    secondaryContainer = AccentSageContainerDark,
    onSecondaryContainer = AccentSageDark,
    tertiary = AccentAmberDark,
    onTertiary = Color(0xFF281904),
    tertiaryContainer = AccentAmberContainerDark,
    onTertiaryContainer = AccentAmberDark,
    background = CanvasBackgroundDark,
    onBackground = InkPrimaryDark,
    surface = SurfaceDark,
    onSurface = InkPrimaryDark,
    surfaceVariant = SurfaceMutedDark,
    onSurfaceVariant = InkSecondaryDark,
    outline = OutlineDark,
    outlineVariant = OutlineDark,
    error = AccentTerracottaDark,
    onError = Color(0xFF2D0B0D),
    errorContainer = AccentTerracottaContainerDark,
    onErrorContainer = AccentTerracottaDark
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun PersonalAppTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val workspacePalette = if (darkTheme) {
        WorkspacePalette(
            canvasBackground = CanvasBackgroundDark,
            canvasDot = CanvasDotDark,
            isDark = true
        )
    } else {
        WorkspacePalette(
            canvasBackground = CanvasBackgroundLight,
            canvasDot = CanvasDotLight,
            isDark = false
        )
    }

    CompositionLocalProvider(LocalWorkspacePalette provides workspacePalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = AppShapes,
            content = content
        )
    }
}
