package com.example.ui.widgets

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DragIndicator
import androidx.compose.material.icons.outlined.OpenInFull
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.capability.ToolValidator
import com.example.domain.model.CanvasWidget
import com.example.domain.model.CardTone
import com.example.ui.theme.LocalWorkspacePalette
import kotlin.math.roundToInt

@Composable
fun CanvasWidgetFrame(
    widget: CanvasWidget,
    isSelected: Boolean,
    canvasZoom: Float,
    densityPxPerDp: Float,
    onSelect: (toggleMulti: Boolean) -> Unit,
    onMoveEnd: (newX: Float, newY: Float) -> Unit,
    onResizeEnd: (newWidth: Float, newHeight: Float) -> Unit,
    content: @Composable (CanvasWidget) -> Unit
) {
    val palette = LocalWorkspacePalette.current
    val accentColors = palette.accentForKey(widget.style.accentColorKey)

    var dragOffsetX by remember(widget.id, widget.x) { mutableFloatStateOf(0f) }
    var dragOffsetY by remember(widget.id, widget.y) { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }

    var resizeDeltaW by remember(widget.id, widget.width) { mutableFloatStateOf(0f) }
    var resizeDeltaH by remember(widget.id, widget.height) { mutableFloatStateOf(0f) }
    var isResizing by remember { mutableStateOf(false) }

    val effectiveX = widget.x + dragOffsetX
    val effectiveY = widget.y + dragOffsetY
    val effectiveW = (widget.width + resizeDeltaW).coerceIn(
        ToolValidator.MIN_WIDGET_WIDTH,
        ToolValidator.MAX_WIDGET_WIDTH
    )
    val effectiveH = (widget.height + resizeDeltaH).coerceIn(
        ToolValidator.MIN_WIDGET_HEIGHT,
        ToolValidator.MAX_WIDGET_HEIGHT
    )

    val containerColor = when (widget.style.cardTone) {
        CardTone.DEFAULT -> MaterialTheme.colorScheme.surface
        CardTone.TINTED -> accentColors.container.copy(alpha = if (palette.isDark) 0.55f else 0.72f)
        CardTone.OUTLINED -> MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
    }

    val borderColor by animateColorAsState(
        targetValue = when {
            isSelected -> accentColors.accent
            widget.style.cardTone == CardTone.OUTLINED -> accentColors.accent.copy(alpha = 0.45f)
            else -> MaterialTheme.colorScheme.outline
        },
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "widgetBorder"
    )

    val cornerShape = RoundedCornerShape(widget.style.cornerRadiusDp.dp)

    Box(
        modifier = Modifier
            .offset {
                IntOffset(
                    x = (effectiveX * densityPxPerDp).roundToInt(),
                    y = (effectiveY * densityPxPerDp).roundToInt()
                )
            }
            .size(width = effectiveW.dp, height = effectiveH.dp)
            .zIndex(if (isSelected || isDragging || isResizing) widget.zIndex + 1000f else widget.zIndex.toFloat())
            .testTag("widget_card_${widget.id}")
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(widget.id, isSelected) {
                    detectTapGestures(
                        onTap = { onSelect(false) },
                        onLongPress = { onSelect(true) }
                    )
                },
            shape = cornerShape,
            color = containerColor,
            shadowElevation = if (isSelected || isDragging) 10.dp else 3.dp,
            border = BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Drag Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isSelected) accentColors.container.copy(alpha = 0.5f)
                            else Color.Transparent
                        )
                        .pointerInput(widget.id, canvasZoom) {
                            detectDragGestures(
                                onDragStart = {
                                    isDragging = true
                                    onSelect(false)
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    dragOffsetX += dragAmount.x / (densityPxPerDp * canvasZoom)
                                    dragOffsetY += dragAmount.y / (densityPxPerDp * canvasZoom)
                                },
                                onDragEnd = {
                                    isDragging = false
                                    onMoveEnd(widget.x + dragOffsetX, widget.y + dragOffsetY)
                                    dragOffsetX = 0f
                                    dragOffsetY = 0f
                                },
                                onDragCancel = {
                                    isDragging = false
                                    dragOffsetX = 0f
                                    dragOffsetY = 0f
                                }
                            )
                        }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(accentColors.accent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = widget.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isSelected) {
                            Text(
                                text = widget.id,
                                style = MaterialTheme.typography.labelSmall,
                                color = accentColors.accent,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                        }
                        Icon(
                            imageVector = Icons.Outlined.DragIndicator,
                            contentDescription = "Drag ${widget.title}",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                )

                // Inner Widget Content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    content(widget)
                }
            }
        }

        // Resize Handle (shown when selected)
        if (isSelected) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(44.dp)
                    .pointerInput(widget.id, canvasZoom) {
                        detectDragGestures(
                            onDragStart = { isResizing = true },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                resizeDeltaW += dragAmount.x / (densityPxPerDp * canvasZoom)
                                resizeDeltaH += dragAmount.y / (densityPxPerDp * canvasZoom)
                            },
                            onDragEnd = {
                                isResizing = false
                                onResizeEnd(effectiveW, effectiveH)
                                resizeDeltaW = 0f
                                resizeDeltaH = 0f
                            },
                            onDragCancel = {
                                isResizing = false
                                resizeDeltaW = 0f
                                resizeDeltaH = 0f
                            }
                        )
                    }
                    .testTag("resize_handle_${widget.id}"),
                contentAlignment = Alignment.BottomEnd
            ) {
                Surface(
                    shape = CircleShape,
                    color = accentColors.accent,
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .padding(4.dp)
                        .size(24.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.OpenInFull,
                            contentDescription = "Resize ${widget.title}",
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }

            if (isResizing) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.inverseSurface,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "${effectiveW.toInt()} × ${effectiveH.toInt()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.inverseOnSurface,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
