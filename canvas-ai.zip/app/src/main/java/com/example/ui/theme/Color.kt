package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Calm architectural light palette
val CanvasBackgroundLight = Color(0xFFF7F8FA)
val CanvasDotLight = Color(0xFFD0D7E2)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceMutedLight = Color(0xFFF0F2F6)
val InkPrimaryLight = Color(0xFF141820)
val InkSecondaryLight = Color(0xFF5A6577)
val OutlineLight = Color(0xFFE1E5ED)

val AccentCobalt = Color(0xFF2F54EB)
val AccentCobaltContainerLight = Color(0xFFEEF2FF)
val AccentSage = Color(0xFF0F766E)
val AccentSageContainerLight = Color(0xFFE6F4F1)
val AccentAmber = Color(0xFFB45309)
val AccentAmberContainerLight = Color(0xFFFEF3C7)
val AccentPlum = Color(0xFF6D28D9)
val AccentPlumContainerLight = Color(0xFFF3E8FF)
val AccentTerracotta = Color(0xFFB91C1C)
val AccentTerracottaContainerLight = Color(0xFFFEE2E2)
val AccentSlate = Color(0xFF334155)
val AccentSlateContainerLight = Color(0xFFF1F5F9)

// Calm architectural dark palette
val CanvasBackgroundDark = Color(0xFF111419)
val CanvasDotDark = Color(0xFF28303D)
val SurfaceDark = Color(0xFF1A1F27)
val SurfaceMutedDark = Color(0xFF232934)
val InkPrimaryDark = Color(0xFFF1F5F9)
val InkSecondaryDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF2D3544)

val AccentCobaltDark = Color(0xFF7596FF)
val AccentCobaltContainerDark = Color(0xFF1E2949)
val AccentSageDark = Color(0xFF4FD1C5)
val AccentSageContainerDark = Color(0xFF133331)
val AccentAmberDark = Color(0xFFFBBF24)
val AccentAmberContainerDark = Color(0xFF3A290D)
val AccentPlumDark = Color(0xFFA78BFA)
val AccentPlumContainerDark = Color(0xFF2C1E4A)
val AccentTerracottaDark = Color(0xFFF87171)
val AccentTerracottaContainerDark = Color(0xFF3E181A)
val AccentSlateDark = Color(0xFFCBD5E1)
val AccentSlateContainerDark = Color(0xFF242B36)
