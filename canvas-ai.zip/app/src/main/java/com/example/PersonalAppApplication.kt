package com.example

import android.app.Application
import com.example.ai.AiProviderRegistry
import com.example.ai.AiWorkspaceOrchestrator
import com.example.capability.CapabilityEngine
import com.example.data.local.db.PersonalAppDatabase
import com.example.data.local.prefs.UserPreferencesRepository
import com.example.data.local.security.SecureCredentialStore
import com.example.data.repository.WorkspaceRepository
import com.example.notifications.ReminderNotificationHelper
import com.example.notifications.ReminderScheduler

class AppContainer(application: Application) {
    val database: PersonalAppDatabase by lazy {
        PersonalAppDatabase.getInstance(application)
    }
    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(application)
    }
    val credentialStore: SecureCredentialStore by lazy {
        SecureCredentialStore(application)
    }
    val workspaceRepository: WorkspaceRepository by lazy {
        WorkspaceRepository(database.personalAppDao(), preferencesRepository)
    }
    val reminderScheduler: ReminderScheduler by lazy {
        ReminderScheduler(application)
    }
    val capabilityEngine: CapabilityEngine by lazy {
        CapabilityEngine(workspaceRepository, reminderScheduler)
    }
    val aiProviderRegistry: AiProviderRegistry by lazy {
        AiProviderRegistry()
    }
    val aiOrchestrator: AiWorkspaceOrchestrator by lazy {
        AiWorkspaceOrchestrator(
            repository = workspaceRepository,
            prefsRepo = preferencesRepository,
            credentialStore = credentialStore,
            providerRegistry = aiProviderRegistry,
            capabilityEngine = capabilityEngine
        )
    }
}

class PersonalAppApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        ReminderNotificationHelper.ensureChannel(this)
    }
}
